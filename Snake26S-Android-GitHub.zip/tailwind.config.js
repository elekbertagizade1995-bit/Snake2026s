/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './App.tsx', './constants.ts', './utils/**/*.{ts,tsx}'],
  theme: {extend: {}},
  plugins: [],
};
