/* Standalone-compatible replacement for the Google Playground SDK bridge. */
import {useCallback, useEffect, useRef, useState} from 'react';
import {FakePlaygroundSDK} from './playground-fake';

export function usePlayground() {
  const [isReady, setIsReady] = useState(false);
  const sdkRef = useRef<any>(null);
  const onGameEventRef = useRef<((event: any) => void) | null>(null);
  const onPresenceEventRef = useRef<((presence: any) => void) | null>(null);
  const onLobbyStatusRef = useRef<((status: any) => void) | null>(null);

  useEffect(() => {
    if (sdkRef.current) return;

    let mounted = true;
    const sdk = new FakePlaygroundSDK();
    sdkRef.current = sdk;

    sdk.init(
      (event: any) => onGameEventRef.current?.(event),
      (presence: any) => onPresenceEventRef.current?.(presence),
      (status: any) => onLobbyStatusRef.current?.(status),
    ).then(() => {
      if (mounted) setIsReady(true);
    }).catch((error: unknown) => {
      console.warn('[Standalone SDK] initialization warning:', error);
      if (mounted) setIsReady(true);
    });

    return () => {
      mounted = false;
    };
  }, []);

  return {
    sdk: sdkRef.current,
    isReady,
    onGameEventRef,
    onPresenceEventRef,
    onLobbyStatusRef,
  };
}

export interface BaseGameState {
  status: string;
  score: number;
  level?: number | string;
}

export function usePlaygroundGameLifecycle(gameState: BaseGameState, sdk?: any) {
  const defaultHook = usePlayground();
  const activeSdk = sdk ?? defaultHook.sdk;
  const hasCalledGameOver = useRef(false);
  const hasCalledLevelComplete = useRef(false);
  const lastScoreRef = useRef(gameState.score);
  const lastLevelRef = useRef(gameState.level);
  const lastIsPausedRef = useRef(false);

  lastScoreRef.current = gameState.score;
  lastLevelRef.current = gameState.level;

  useEffect(() => {
    if (!activeSdk) return;

    const status = (gameState.status || '').toUpperCase();
    const isGameOver = status === 'GAME_OVER' || status === 'DEFEAT' || status === 'LOST';
    const isLevelComplete = status === 'VICTORY' || status === 'WIN' || status === 'LEVEL_COMPLETE';
    const currentLevel = gameState.level ?? 1;
    const isPaused = status === 'PAUSED' || status === 'PAUSE';

    if (lastIsPausedRef.current !== isPaused) {
      activeSdk.pauseStateChanged?.(isPaused);
      lastIsPausedRef.current = isPaused;
    }

    if (status === 'PLAYING') {
      activeSdk.scoreUpdated?.({value: gameState.score, level: String(currentLevel)});
      hasCalledGameOver.current = false;
      hasCalledLevelComplete.current = false;
    } else if (isGameOver && !hasCalledGameOver.current) {
      activeSdk.scoreUpdated?.({value: gameState.score, level: String(currentLevel)});
      activeSdk.gameOver?.();
      hasCalledGameOver.current = true;
    } else if (isLevelComplete && !hasCalledLevelComplete.current) {
      activeSdk.scoreUpdated?.({value: gameState.score, level: String(currentLevel)});
      activeSdk.levelComplete?.(currentLevel);
      hasCalledLevelComplete.current = true;
    }
  }, [gameState.score, gameState.status, gameState.level, activeSdk]);

  useEffect(() => () => {
    if (activeSdk && !hasCalledGameOver.current && !hasCalledLevelComplete.current && lastScoreRef.current > 0) {
      try {
        activeSdk.scoreUpdated?.({value: lastScoreRef.current, level: String(lastLevelRef.current ?? 1)});
        activeSdk.gameOver?.();
      } catch (_) {}
    }
  }, [activeSdk]);
}

export function useRpc<RequestType, ResponseType>(
  _rpcName: string,
): [(payload: RequestType) => Promise<ResponseType>, boolean] {
  const [isLoading, setIsLoading] = useState(false);
  const callRpc = useCallback(async (_payload: RequestType): Promise<ResponseType> => {
    setIsLoading(true);
    try {
      // Playground's parent-window RPC has no meaning in a standalone APK.
      // Resolve immediately so buttons such as Exit never hang.
      return undefined as ResponseType;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return [callRpc, isLoading];
}

export type NumberConfigEntry = {value: number; type: 'number'; label: string; group: string; min?: number; max?: number; step?: number};
export type BooleanConfigEntry = {value: boolean; type: 'boolean'; label: string; group: string};
export type ColorConfigEntry = {value: string; type: 'color'; label: string; group: string};
export type SelectConfigEntry = {value: string; type: 'select'; label: string; group: string; options: string[]};
export type Vector2ConfigEntry = {value: {x: number; y: number}; type: 'vector2'; label: string; group: string};
export type ConfigEntry = NumberConfigEntry | BooleanConfigEntry | ColorConfigEntry | SelectConfigEntry | Vector2ConfigEntry;
export type GameConfig = Record<string, ConfigEntry>;
export type ConfigValues<T extends GameConfig> = {[K in keyof T]: T[K]['value']};
