# Snake 26S - Android APK build

This project was adapted from the Google Playground export for standalone Android use.

## What changed
- The Google Playground remote SDK is no longer loaded.
- A local standalone SDK bridge is used instead, so the game can run outside Playground.
- Playground parent-window RPC calls are converted to safe no-op calls so the APK does not hang waiting for Playground.
- Vite + React + TypeScript build setup was added.
- Tailwind CSS build setup was added because the original game uses Tailwind utility classes.
- Capacitor Android configuration was added.
- GitHub Actions workflow builds a debug APK automatically.

## GitHub phone-only build
1. Create a new GitHub repository.
2. Upload all files from this ZIP to the repository root.
3. Open **Actions** and select **Build Snake 26S APK**.
4. Press **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run and download the artifact named **Snake-26S-debug-apk**.
7. Extract the artifact and install `app-debug.apk` on Android.

The workflow creates the Android project on the GitHub runner, so an Android Studio installation is not required on the phone.
