export interface Point {
  x: number;
  y: number;
}

export interface MapConfig {
  id: string;
  name: string;
  bgKey: string;
  theme: 'classic' | 'forest' | 'desert' | 'ice' | 'night';
  obstacleType: 'none' | 'rock' | 'ice' | 'night_crystal';
  accentColor: string;
  borderColor: string;
  description: string;
  obstacles: Array<{ x: number; y: number }>;
}

export interface SnakeSkin {
  id: string;
  name: string;
  primary: string;
  secondary: string;
  glow: string;
  belly: string;
  eyeColor?: string;
}

export type SpeedMode = 'BEGINNER' | 'AMATEUR' | 'PRO';

export interface SpeedSetting {
  id: SpeedMode;
  label: string;
  sublabel: string;
  initialSpeed: number; // steps per second (e.g. 5.0 = ~0.20s/step)
  stepIntervalSec: number;
  color: string;
}

export const SPEED_PRESETS: Record<SpeedMode, SpeedSetting> = {
  BEGINNER: {
    id: 'BEGINNER',
    label: 'BEGINNER',
    sublabel: 'Relaxed & easy (~0.20s/step)',
    initialSpeed: 5.0,
    stepIntervalSec: 0.20,
    color: '#34d399',
  },
  AMATEUR: {
    id: 'AMATEUR',
    label: 'AMATEUR',
    sublabel: 'Standard pace (~0.14s/step)',
    initialSpeed: 7.2,
    stepIntervalSec: 0.14,
    color: '#38bdf8',
  },
  PRO: {
    id: 'PRO',
    label: 'PRO',
    sublabel: 'Fast reflexes (~0.09s/step)',
    initialSpeed: 10.5,
    stepIntervalSec: 0.095,
    color: '#f87171',
  },
};

export const SNAKE_SKINS: SnakeSkin[] = [
  {
    id: 'emerald',
    name: 'Emerald Green',
    primary: '#10b981',
    secondary: '#059669',
    glow: '#34d399',
    belly: '#a7f3d0',
  },
  {
    id: 'electric_blue',
    name: 'Electric Cyan',
    primary: '#06b6d4',
    secondary: '#0284c7',
    glow: '#38bdf8',
    belly: '#bae6fd',
  },
  {
    id: 'ruby_red',
    name: 'Ruby Crimson',
    primary: '#ef4444',
    secondary: '#b91c1c',
    glow: '#f87171',
    belly: '#fecaca',
  },
  {
    id: 'golden_sun',
    name: 'Golden Sun',
    primary: '#eab308',
    secondary: '#ca8a04',
    glow: '#fde047',
    belly: '#fef08a',
  },
  {
    id: 'amethyst_violet',
    name: 'Royal Violet',
    primary: '#a855f7',
    secondary: '#7e22ce',
    glow: '#c084fc',
    belly: '#e9d5ff',
  },
  {
    id: 'coral_pink',
    name: 'Coral Peachy',
    primary: '#f43f5e',
    secondary: '#e11d48',
    glow: '#fb7185',
    belly: '#ffe4e6',
  },
  {
    id: 'lime_citrus',
    name: 'Lime Citrus',
    primary: '#84cc16',
    secondary: '#65a30d',
    glow: '#a3e635',
    belly: '#d9f99d',
  },
  {
    id: 'midnight_neon',
    name: 'Midnight Shadow',
    primary: '#6366f1',
    secondary: '#4338ca',
    glow: '#818cf8',
    belly: '#c7d2fe',
  },
];

export const MAPS: MapConfig[] = [
  {
    id: 'classic',
    name: 'Classic Turf',
    bgKey: 'bg_classic',
    theme: 'classic',
    obstacleType: 'none',
    accentColor: '#38bdf8',
    borderColor: '#0284c7',
    description: 'Vibrant arcade turf with polished curved walls & maximum open slithering space.',
    obstacles: [],
  },
  {
    id: 'forest',
    name: 'Forest Canopy',
    bgKey: 'bg_forest',
    theme: 'forest',
    obstacleType: 'rock',
    accentColor: '#4ade80',
    borderColor: '#15803d',
    description: 'Lush cartoon meadow with leafy borders & ancient mossy boulders.',
    obstacles: [
      { x: 3, y: 4 },
      { x: 4, y: 4 },
      { x: 3, y: 5 },
      { x: 4, y: 5 },
      { x: 13, y: 4 },
      { x: 14, y: 4 },
      { x: 13, y: 5 },
      { x: 14, y: 5 },
      { x: 3, y: 16 },
      { x: 4, y: 16 },
      { x: 3, y: 17 },
      { x: 4, y: 17 },
      { x: 13, y: 16 },
      { x: 14, y: 16 },
      { x: 13, y: 17 },
      { x: 14, y: 17 },
      { x: 2, y: 10 },
      { x: 2, y: 11 },
      { x: 15, y: 10 },
      { x: 15, y: 11 },
    ],
  },
  {
    id: 'desert',
    name: 'Desert Oasis',
    bgKey: 'bg_desert',
    theme: 'desert',
    obstacleType: 'rock',
    accentColor: '#fbbf24',
    borderColor: '#b45309',
    description: 'Warm sandstone tiles with clay stones and tight corner chokepoints.',
    obstacles: [
      { x: 3, y: 3 },
      { x: 4, y: 3 },
      { x: 3, y: 4 },
      { x: 14, y: 3 },
      { x: 13, y: 3 },
      { x: 14, y: 4 },
      { x: 3, y: 18 },
      { x: 4, y: 18 },
      { x: 3, y: 17 },
      { x: 14, y: 18 },
      { x: 13, y: 18 },
      { x: 14, y: 17 },
      { x: 4, y: 10 },
      { x: 4, y: 11 },
      { x: 13, y: 10 },
      { x: 13, y: 11 },
    ],
  },
  {
    id: 'ice',
    name: 'Glacier Freeze',
    bgKey: 'bg_ice',
    theme: 'ice',
    obstacleType: 'ice',
    accentColor: '#67e8f9',
    borderColor: '#0891b2',
    description: 'Crystalline frozen lake with translucent ice blocks and snowy trim.',
    obstacles: [
      { x: 4, y: 5 },
      { x: 4, y: 6 },
      { x: 4, y: 7 },
      { x: 4, y: 14 },
      { x: 4, y: 15 },
      { x: 4, y: 16 },
      { x: 13, y: 5 },
      { x: 13, y: 6 },
      { x: 13, y: 7 },
      { x: 13, y: 14 },
      { x: 13, y: 15 },
      { x: 13, y: 16 },
      { x: 8, y: 3 },
      { x: 9, y: 3 },
      { x: 8, y: 19 },
      { x: 9, y: 19 },
    ],
  },
  {
    id: 'night',
    name: 'Neon Twilight',
    bgKey: 'bg_night',
    theme: 'night',
    obstacleType: 'night_crystal',
    accentColor: '#c084fc',
    borderColor: '#7e22ce',
    description: 'Bioluminescent midnight turf with floating fireflies and neon crystals.',
    obstacles: [
      { x: 3, y: 5 },
      { x: 4, y: 6 },
      { x: 3, y: 7 },
      { x: 14, y: 5 },
      { x: 13, y: 6 },
      { x: 14, y: 7 },
      { x: 3, y: 14 },
      { x: 4, y: 15 },
      { x: 3, y: 16 },
      { x: 14, y: 14 },
      { x: 13, y: 15 },
      { x: 14, y: 16 },
      { x: 8, y: 3 },
      { x: 9, y: 3 },
      { x: 8, y: 19 },
      { x: 9, y: 19 },
    ],
  },
];

/**
 * Checks whether a given grid coordinate falls inside the guaranteed Safe Spawn Zone.
 * - Snake initial head & body segments
 * - 1-cell protective halo around every snake segment
 * - Forward trajectory corridor (at least 6 cells ahead of the head)
 * - Immediate lateral flank (1 cell left & right along the forward corridor) for safe early turning
 */
/**
 * Checks whether a given grid coordinate falls inside the guaranteed Safe Spawn Zone.
 * - Snake initial head & body segments
 * - 1-cell protective halo around every snake segment
 * - Forward trajectory corridor (at least 6 cells ahead of the head)
 * - Immediate lateral flank (1 cell left & right along the forward corridor) for safe early turning
 */
export function isCellInSafeSpawnZone(
  x: number,
  y: number,
  head: Point,
  dir: Point,
  snakeLength: number,
  corridorSteps = 6,
  haloRadius = 1,
): boolean {
  // 1. Check snake body segments & their safety halo
  for (let i = 0; i < snakeLength; i++) {
    const segX = head.x - dir.x * i;
    const segY = head.y - dir.y * i;
    if (Math.abs(x - segX) <= haloRadius && Math.abs(y - segY) <= haloRadius) {
      return true;
    }
  }

  // 2. Check forward corridor ahead of head with lateral flank for guaranteed turning safety
  const perpX = -dir.y;
  const perpY = dir.x;

  for (let step = 1; step <= corridorSteps; step++) {
    const cx = head.x + dir.x * step;
    const cy = head.y + dir.y * step;
    for (let flank = -1; flank <= 1; flank++) {
      const fx = cx + perpX * flank;
      const fy = cy + perpY * flank;
      if (x === fx && y === fy) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Validates and algorithmically sanitizes obstacle placements for any map.
 * If an obstacle collides with the Safe Spawn Zone or falls out of bounds,
 * it is relocated to the nearest valid open cell outside the safe zone.
 */
export function getSanitizedMapObstacles(
  rawObstacles: Array<{ x: number; y: number }>,
  gridCols: number,
  gridRows: number,
  head: Point,
  dir: Point,
  snakeLength: number,
): Array<{ x: number; y: number }> {
  const sanitized: Array<{ x: number; y: number }> = [];
  const occupied = new Set<string>();

  // Mark all safe spawn zone cells as reserved so no obstacles can occupy them
  for (let c = 0; c < gridCols; c++) {
    for (let r = 0; r < gridRows; r++) {
      if (isCellInSafeSpawnZone(c, r, head, dir, snakeLength)) {
        occupied.add(`${c},${r}`);
      }
    }
  }

  for (const obs of rawObstacles) {
    const targetX = Math.round(obs.x);
    const targetY = Math.round(obs.y);

    const isInsideGrid =
      targetX >= 1 &&
      targetX < gridCols - 1 &&
      targetY >= 1 &&
      targetY < gridRows - 1;

    const key = `${targetX},${targetY}`;

    if (isInsideGrid && !occupied.has(key)) {
      sanitized.push({ x: targetX, y: targetY });
      occupied.add(key);
    } else {
      // Find valid relocation spot outside safe zone
      let found = false;
      const maxRadius = Math.max(gridCols, gridRows);
      for (let radius = 1; radius < maxRadius && !found; radius++) {
        for (let dx = -radius; dx <= radius && !found; dx++) {
          for (let dy = -radius; dy <= radius && !found; dy++) {
            if (Math.abs(dx) !== radius && Math.abs(dy) !== radius) continue;
            const nx = targetX + dx;
            const ny = targetY + dy;

            if (
              nx >= 1 &&
              nx < gridCols - 1 &&
              ny >= 1 &&
              ny < gridRows - 1
            ) {
              const newKey = `${nx},${ny}`;
              if (!occupied.has(newKey)) {
                sanitized.push({ x: nx, y: ny });
                occupied.add(newKey);
                found = true;
              }
            }
          }
        }
      }
    }
  }

  return sanitized;
}

/**
 * Configuration for the game.
 * Optimized for mobile-first full screen & arcade clarity.
 */
export const CONFIG = {
  title: {
    value: 'Snake 26s',
    type: 'string',
    label: 'Game Title',
    group: 'GAME',
  },
  baseCanvasWidth: {
    value: 756,
    type: 'number',
    label: 'Base Canvas Width',
    group: 'GAME',
  },
  baseCanvasHeight: {
    value: 966,
    type: 'number',
    label: 'Base Canvas Height',
    group: 'GAME',
  },

  // System Constants
  targetFPS: {
    value: 60,
    type: 'number',
    label: 'Target FPS',
    group: 'SYSTEM',
  },
  stepMs: {
    value: 1000 / 60,
    type: 'number',
    label: 'Step MS',
    group: 'SYSTEM',
  },
  maxSubSteps: {
    value: 5,
    type: 'number',
    label: 'Max Sub Steps',
    group: 'SYSTEM',
  },

  // Thematic elements
  backgroundColor: {
    value: '#090d16',
    type: 'color',
    label: 'Background Color',
    group: 'THEME',
  },
  primaryColor: {
    value: '#10b981',
    type: 'color',
    label: 'Primary Color',
    group: 'THEME',
  },
  fontFamily: {
    value: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    type: 'string',
    label: 'Font Family',
    group: 'THEME',
  },

  // Standard audio levels
  defaultMusicVolume: {
    value: 0.35,
    type: 'number',
    label: 'Default Music Volume',
    group: 'AUDIO',
  },
  defaultSfxVolume: {
    value: 0.6,
    type: 'number',
    label: 'Default SFX Volume',
    group: 'AUDIO',
  },

  // Grid Configuration: 18 cols x 22 rows = 756 x 924 + top/bottom padding
  gridCols: {
    value: 18,
    type: 'number',
    label: 'Grid Columns',
    group: 'Grid',
  },
  gridRows: {
    value: 22,
    type: 'number',
    label: 'Grid Rows',
    group: 'Grid',
  },
  tileSize: {
    value: 42,
    type: 'number',
    label: 'Tile Size (px)',
    group: 'Grid',
  },
  arenaOffsetX: {
    value: 0,
    type: 'number',
    label: 'Arena Offset X',
    group: 'Grid',
  },
  arenaOffsetY: {
    value: 21,
    type: 'number',
    label: 'Arena Offset Y',
    group: 'Grid',
  },

  // Rules & Movement Dynamics
  initialSpeed: {
    value: 6.0,
    type: 'number',
    label: 'Initial Speed (steps/s)',
    group: 'Rules',
  },
  speedIncrementPerFood: {
    value: 0.12,
    type: 'number',
    label: 'Speed Increment Per Food',
    group: 'Rules',
  },
  maxSpeed: {
    value: 14.5,
    type: 'number',
    label: 'Max Speed (steps/s)',
    group: 'Rules',
  },
  pointsPerFrog: {
    value: 10,
    type: 'number',
    label: 'Points Per Frog',
    group: 'Rules',
  },
  startingSnakeLength: {
    value: 4,
    type: 'number',
    label: 'Starting Snake Length',
    group: 'Rules',
  },
};

// Merge customized config values if present (injected by Playground)
const { playgroundConfig } = globalThis as {
  playgroundConfig?: Record<string, unknown>;
};
if (playgroundConfig) {
  for (const [key, value] of Object.entries(playgroundConfig)) {
    if (key in CONFIG) {
      Object.assign(CONFIG[key as keyof typeof CONFIG], { value });
    }
  }
}

export type ConfigKey = keyof typeof CONFIG;

export function getConfig<K extends ConfigKey>(
  key: K,
): (typeof CONFIG)[K]['value'] {
  return CONFIG[key].value;
}

export const PRESETS = {};
