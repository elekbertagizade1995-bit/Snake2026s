// tslint:disable
/* eslint-disable */
import {
  ChevronLeft,
  ChevronRight,
  Flame,
  HelpCircle,
  Menu,
  Music,
  Palette,
  Pause,
  Play,
  RotateCw,
  Settings,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  CONFIG,
  getConfig,
  getSanitizedMapObstacles,
  isCellInSafeSpawnZone,
  MAPS,
  MapConfig,
  Point,
  SNAKE_SKINS,
  SnakeSkin,
  SpeedMode,
  SPEED_PRESETS,
} from './constants';
import BackgroundMusic from './utils/BackgroundMusic';
import {
  createFixedStepper,
  drawAsset,
  drawBackground,
  gameAudio,
  GameState,
  MenuOverlay,
  Overlay,
  prepareCanvas,
  useAssets,
  useAutoFocus,
  useInput,
  useIsMobile,
} from './utils/helper';
import {
  usePlayground,
  usePlaygroundGameLifecycle,
  useRpc,
} from './utils/usePlayground';

const BACKGROUND_MUSIC_URL = 'assets/audio/bgm_arcade_loop.mp3';

interface FloatingText {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  alpha: number;
  scale: number;
  vy: number;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  maxLife: number;
  life: number;
}

interface Firefly {
  x: number;
  y: number;
  vx: number;
  vy: number;
  phase: number;
  size: number;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stepperRef = useRef<ReturnType<typeof createFixedStepper>>();
  const lastCancelRef = useRef(false);

  // Playground SDK Integration
  const { sdk, isReady } = usePlayground();
  const [exitChat] = useRpc<Record<string, unknown>, void>('ExitChat');

  const isMobile = useIsMobile();

  // Assets Manifest
  const ASSETS_MANIFEST: Record<string, string> = {
    frog_food: 'assets/images/frog_food.png',
    snake_head: 'assets/images/snake_head_sprite.png',
    dizzy_star: 'assets/images/dizzy_star.png',
    obstacle_rock: 'assets/images/obstacle_rock.png',
    obstacle_ice_block: 'assets/images/obstacle_ice_block.png',
    bg_classic: 'assets/images/bg_classic.png',
    bg_forest: 'assets/images/bg_forest.png',
    bg_desert: 'assets/images/bg_desert.png',
    bg_ice: 'assets/images/bg_ice.png',
    bg_night: 'assets/images/bg_night.png',
  };
  const { assets, isReady: assetsReady, progress: rawProgress } = useAssets(ASSETS_MANIFEST);

  // Smooth loading progress & transition state
  const [displayProgress, setDisplayProgress] = useState(0);
  const [loadingFadingOut, setLoadingFadingOut] = useState(false);
  const [isLoaderMounted, setIsLoaderMounted] = useState(true);

  useEffect(() => {
    let animationFrameId: number;
    const target = assetsReady ? 1 : Math.max(0.15, rawProgress);
    const updateProgress = () => {
      setDisplayProgress((prev) => {
        const diff = target - prev;
        if (Math.abs(diff) < 0.01) return target;
        return prev + diff * 0.15;
      });
      animationFrameId = requestAnimationFrame(updateProgress);
    };
    animationFrameId = requestAnimationFrame(updateProgress);
    return () => cancelAnimationFrame(animationFrameId);
  }, [assetsReady, rawProgress]);

  useEffect(() => {
    if (assetsReady && displayProgress >= 0.98) {
      const timer = setTimeout(() => {
        setLoadingFadingOut(true);
        const unmountTimer = setTimeout(() => {
          setIsLoaderMounted(false);
        }, 500);
        return () => clearTimeout(unmountTimer);
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [assetsReady, displayProgress]);

  const canvasWidth = getConfig('baseCanvasWidth') as number;
  const canvasHeight = getConfig('baseCanvasHeight') as number;

  if (!stepperRef.current) {
    const stepMs = getConfig('stepMs');
    const maxSubSteps = getConfig('maxSubSteps');
    stepperRef.current = createFixedStepper(stepMs, maxSubSteps);
  }

  // Reactive UI Game State
  const [gameState, setGameState] = useState<GameState>({
    status: 'START',
    score: 0,
    level: 1,
  });

  const gameStateRef = useRef(gameState);
  gameStateRef.current = gameState;

  // Selected Map, Skin, and Speed Mode
  const [selectedMapIndex, setSelectedMapIndex] = useState(0);
  const [selectedSkinIndex, setSelectedSkinIndex] = useState(0);
  const [speedMode, setSpeedMode] = useState<SpeedMode>(() => {
    try {
      const saved = localStorage.getItem('snake26s_speed') as SpeedMode;
      if (saved && SPEED_PRESETS[saved]) return saved;
    } catch {}
    return 'BEGINNER';
  });

  // Modals & Overlays
  const [isGameMenuOpen, setIsGameMenuOpen] = useState(false);
  const [isHowToPlayOpen, setIsHowToPlayOpen] = useState(false);
  const [isSkinModalOpen, setIsSkinModalOpen] = useState(false);
  const [isMapModalOpen, setIsMapModalOpen] = useState(false);

  // Independent Audio Toggles with persistence
  const [isMusicMuted, setIsMusicMuted] = useState(() => {
    try {
      const saved = localStorage.getItem('snake26s_music_enabled');
      return saved === 'false';
    } catch {
      return false;
    }
  });

  const [isSfxMuted, setIsSfxMuted] = useState(() => {
    try {
      const saved = localStorage.getItem('snake26s_sfx_enabled');
      return saved === 'false';
    } catch {
      return false;
    }
  });

  const [isHapticEnabled, setIsHapticEnabled] = useState(true);
  const [highScores, setHighScores] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('snake26s_highscores');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const currentMap = MAPS[selectedMapIndex] || MAPS[0];
  const currentSkin = SNAKE_SKINS[selectedSkinIndex] || SNAKE_SKINS[0];
  const currentSpeedConfig = SPEED_PRESETS[speedMode] || SPEED_PRESETS.BEGINNER;

  const handleSelectSpeed = useCallback((mode: SpeedMode) => {
    setSpeedMode(mode);
    try {
      localStorage.setItem('snake26s_speed', mode);
    } catch {}
    gameAudio.playCrispClick();
    if (gameStateRef.current.status === 'PLAYING') {
      currentSpeedRef.current = SPEED_PRESETS[mode].initialSpeed;
    }
  }, []);

  const handleToggleMusic = useCallback(() => {
    setIsMusicMuted((prev) => {
      const next = !prev;
      gameAudio.setMusicMuted(next);
      try {
        localStorage.setItem('snake26s_music_enabled', (!next).toString());
      } catch {}
      return next;
    });
    gameAudio.playCrispClick();
  }, []);

  const handleToggleSfx = useCallback(() => {
    setIsSfxMuted((prev) => {
      const next = !prev;
      gameAudio.setSfxMuted(next);
      try {
        localStorage.setItem('snake26s_sfx_enabled', (!next).toString());
      } catch {}
      return next;
    });
    gameAudio.playCrispClick();
  }, []);

  useEffect(() => {
    (window as any).canHandleBackKey = gameState.status !== 'START';
  }, [gameState.status]);

  const inputRef = useInput(canvasRef, true, {
    width: canvasWidth,
    height: canvasHeight,
  });

  // --- High-Frequency Simulation State (stored in refs) ---
  const gridCols = getConfig('gridCols') as number;
  const gridRows = getConfig('gridRows') as number;
  const tileSize = getConfig('tileSize') as number;
  const arenaOffsetX = getConfig('arenaOffsetX') as number;
  const arenaOffsetY = getConfig('arenaOffsetY') as number;

  const snakeRef = useRef<Point[]>([]);
  const prevSnakeRef = useRef<Point[]>([]);
  const directionRef = useRef<Point>({ x: 0, y: -1 });
  const nextDirectionQueueRef = useRef<Point[]>([]);
  const foodRef = useRef<Point>({ x: 9, y: 8 });
  const activeObstaclesRef = useRef<Point[]>([]);
  const stepTimerRef = useRef(0);
  const currentSpeedRef = useRef(getConfig('initialSpeed') as number);

  // Visual effects refs
  const frogHopTimerRef = useRef(0);
  const tongueTimerRef = useRef(0);
  const frogEatScaleRef = useRef(1);
  const headEatScaleRef = useRef(1);
  const dizzyAngleRef = useRef(0);
  const floatingTextsRef = useRef<FloatingText[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const firefliesRef = useRef<Firefly[]>([]);
  const screenShakeRef = useRef(0);
  const isDeadRef = useRef(false);
  const deathTimerRef = useRef(0);

  // Initialize background fireflies
  useEffect(() => {
    const flies: Firefly[] = [];
    for (let i = 0; i < 18; i++) {
      flies.push({
        x: Math.random() * canvasWidth,
        y: Math.random() * canvasHeight,
        vx: (Math.random() - 0.5) * 20,
        vy: (Math.random() - 0.5) * 20,
        phase: Math.random() * Math.PI * 2,
        size: 1.5 + Math.random() * 2.5,
      });
    }
    firefliesRef.current = flies;
  }, [canvasWidth, canvasHeight]);

  // Touch Swipe tracking
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);

  // Save High Scores
  const saveHighScore = useCallback(
    (mapId: string, score: number) => {
      setHighScores((prev) => {
        const currentBest = prev[mapId] || 0;
        if (score > currentBest) {
          const updated = { ...prev, [mapId]: score };
          try {
            localStorage.setItem(
              'snake26s_highscores',
              JSON.stringify(updated),
            );
          } catch {}
          return updated;
        }
        return prev;
      });
    },
    [],
  );

  // Trigger Haptic
  const triggerHaptic = useCallback(
    (pattern: number | number[]) => {
      if (
        !isHapticEnabled ||
        typeof navigator === 'undefined' ||
        typeof navigator.vibrate !== 'function'
      ) {
        return;
      }
      if (
        typeof (navigator as any).userActivation !== 'undefined' &&
        !(navigator as any).userActivation?.hasBeenActive
      ) {
        return;
      }
      try {
        navigator.vibrate(pattern);
      } catch {}
    },
    [isHapticEnabled],
  );

  // Spawn new frog away from snake and obstacles
  const spawnFood = useCallback((isInitial = false) => {
    const obstacles = activeObstaclesRef.current;
    const snake = snakeRef.current;
    const occupied = new Set<string>();

    for (const seg of snake) {
      occupied.add(`${seg.x},${seg.y}`);
    }
    for (const obs of obstacles) {
      occupied.add(`${obs.x},${obs.y}`);
    }

    // On initial spawn, prevent food from appearing immediately on top of or 1-2 tiles ahead of head
    if (isInitial && snake.length > 0) {
      const head = snake[0];
      const dir = directionRef.current;
      occupied.add(`${head.x + dir.x},${head.y + dir.y}`);
      occupied.add(`${head.x + dir.x * 2},${head.y + dir.y * 2}`);
    }

    const freeSpots: Point[] = [];
    for (let c = 1; c < gridCols - 1; c++) {
      for (let r = 1; r < gridRows - 1; r++) {
        if (!occupied.has(`${c},${r}`)) {
          freeSpots.push({ x: c, y: r });
        }
      }
    }

    if (freeSpots.length > 0) {
      const picked = freeSpots[Math.floor(Math.random() * freeSpots.length)];
      foodRef.current = picked;
    } else {
      foodRef.current = {
        x: Math.floor(gridCols / 2),
        y: 6,
      };
    }
  }, [gridCols, gridRows]);

  // Turn Request with Fairness buffering
  const requestDirection = useCallback((dir: Point) => {
    const lastDir =
      nextDirectionQueueRef.current.length > 0
        ? nextDirectionQueueRef.current[nextDirectionQueueRef.current.length - 1]
        : directionRef.current;

    // Reject 180° reverse turns into self
    if (dir.x === -lastDir.x && dir.y === -lastDir.y) return;
    // Reject duplicate redundant turns
    if (dir.x === lastDir.x && dir.y === lastDir.y) return;

    // Buffer up to 2 direction presses
    if (nextDirectionQueueRef.current.length < 2) {
      nextDirectionQueueRef.current.push(dir);
    }
  }, []);

  // Synchronize sanitized obstacles whenever map changes
  useEffect(() => {
    const startLen = (getConfig('startingSnakeLength') as number) || 4;
    const startX = Math.floor(gridCols / 2);
    const startY = Math.floor(gridRows / 2) + 2;
    activeObstaclesRef.current = getSanitizedMapObstacles(
      currentMap.obstacles || [],
      gridCols,
      gridRows,
      { x: startX, y: startY },
      { x: 0, y: -1 },
      startLen,
    );
  }, [currentMap, gridCols, gridRows]);

  // Initialize Game with Guaranteed Safe Spawn & Clear Corridor
  const initGame = useCallback(() => {
    const startLen = getConfig('startingSnakeLength') as number;
    const startX = Math.floor(gridCols / 2); // column 9
    const startY = Math.floor(gridRows / 2) + 2; // row 13 (ample 7+ cells to top wall)
    const initialDir: Point = { x: 0, y: -1 }; // start slithering UP

    const initialSnake: Point[] = [];
    for (let i = 0; i < startLen; i++) {
      initialSnake.push({ x: startX, y: startY + i });
    }

    snakeRef.current = initialSnake;
    prevSnakeRef.current = initialSnake.map((p) => ({ ...p }));
    directionRef.current = { ...initialDir };
    nextDirectionQueueRef.current = [];

    // Algorithmic obstacle sanitization ensuring 100% clear safe spawn zone & corridor
    const sanitizedObs = getSanitizedMapObstacles(
      currentMap.obstacles || [],
      gridCols,
      gridRows,
      { x: startX, y: startY },
      initialDir,
      startLen,
    );
    activeObstaclesRef.current = sanitizedObs;

    stepTimerRef.current = 0;
    currentSpeedRef.current =
      SPEED_PRESETS[speedMode]?.initialSpeed ??
      (getConfig('initialSpeed') as number);
    frogHopTimerRef.current = 0;
    tongueTimerRef.current = 0;
    frogEatScaleRef.current = 1;
    headEatScaleRef.current = 1;
    dizzyAngleRef.current = 0;
    floatingTextsRef.current = [];
    particlesRef.current = [];
    screenShakeRef.current = 0;
    isDeadRef.current = false;
    deathTimerRef.current = 0;

    spawnFood(true);

    setGameState({
      status: 'PLAYING',
      score: 0,
      level: selectedMapIndex + 1,
    });
    setIsGameMenuOpen(false);
    setIsHowToPlayOpen(false);

    gameAudio.playConfirmSelect();

    if (sdk) {
      sdk.startGame();
    }
  }, [gridCols, gridRows, currentMap, selectedMapIndex, speedMode, spawnFood, sdk]);

  // Play defeat sound effect on game over
  useEffect(() => {
    if (gameState.status === 'GAME_OVER') {
      gameAudio.playDefeatMotif();
    }
  }, [gameState.status]);

  // Playground SDK Lifecycle
  usePlaygroundGameLifecycle(gameState, sdk);

  // Auto-start when ?autoplay is in URL
  const hasAutoplayed = useRef(false);
  useEffect(() => {
    if (
      !hasAutoplayed.current &&
      new URLSearchParams(window.location.search).has('autoplay')
    ) {
      hasAutoplayed.current = true;
      initGame();
    }
  }, [initGame]);

  // --- Keyboard & Touch Listeners ---
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameStateRef.current.status !== 'PLAYING') return;

      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        requestDirection({ x: 0, y: -1 });
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        requestDirection({ x: 0, y: 1 });
      } else if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        requestDirection({ x: -1, y: 0 });
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        requestDirection({ x: 1, y: 0 });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [requestDirection]);

  // Touch Swipe Handlers
  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      touchStartPos.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY,
      };
    }
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartPos.current || e.changedTouches.length === 0) return;
    const dx = e.changedTouches[0].clientX - touchStartPos.current.x;
    const dy = e.changedTouches[0].clientY - touchStartPos.current.y;
    const minSwipeDist = 20;

    if (Math.hypot(dx, dy) >= minSwipeDist) {
      if (Math.abs(dx) > Math.abs(dy)) {
        if (dx > 0) requestDirection({ x: 1, y: 0 });
        else requestDirection({ x: -1, y: 0 });
      } else {
        if (dy > 0) requestDirection({ x: 0, y: 1 });
        else requestDirection({ x: 0, y: -1 });
      }
    }
    touchStartPos.current = null;
  };

  // --- Simulation Update Loop ---
  const update = (deltaTime: number) => {
    frogHopTimerRef.current += deltaTime * 5;
    tongueTimerRef.current += deltaTime * 3;

    if (frogEatScaleRef.current > 1) {
      frogEatScaleRef.current = Math.max(
        1,
        frogEatScaleRef.current - deltaTime * 4,
      );
    }
    if (headEatScaleRef.current > 1) {
      headEatScaleRef.current = Math.max(
        1,
        headEatScaleRef.current - deltaTime * 4,
      );
    }
    if (screenShakeRef.current > 0) {
      screenShakeRef.current = Math.max(
        0,
        screenShakeRef.current - deltaTime * 20,
      );
    }

    // Update Fireflies
    for (const ff of firefliesRef.current) {
      ff.x += ff.vx * deltaTime;
      ff.y += ff.vy * deltaTime;
      ff.phase += deltaTime * 2;
      if (ff.x < 0) ff.x = canvasWidth;
      if (ff.x > canvasWidth) ff.x = 0;
      if (ff.y < 0) ff.y = canvasHeight;
      if (ff.y > canvasHeight) ff.y = 0;
    }

    // Update Floating Texts
    for (let i = floatingTextsRef.current.length - 1; i >= 0; i--) {
      const ft = floatingTextsRef.current[i];
      ft.y += ft.vy * deltaTime;
      ft.alpha -= deltaTime * 1.5;
      ft.scale = Math.min(1.4, ft.scale + deltaTime * 0.8);
      if (ft.alpha <= 0) {
        floatingTextsRef.current.splice(i, 1);
      }
    }

    // Update Particles
    for (let i = particlesRef.current.length - 1; i >= 0; i--) {
      const p = particlesRef.current[i];
      p.x += p.vx * deltaTime;
      p.y += p.vy * deltaTime;
      p.life += deltaTime;
      p.alpha = Math.max(0, 1 - p.life / p.maxLife);
      if (p.life >= p.maxLife) {
        particlesRef.current.splice(i, 1);
      }
    }

    // If dead: spin dizzy stars and show game over
    if (isDeadRef.current) {
      dizzyAngleRef.current += deltaTime * 6;
      deathTimerRef.current += deltaTime;
      if (
        deathTimerRef.current >= 1.0 &&
        gameStateRef.current.status === 'PLAYING'
      ) {
        saveHighScore(currentMap.id, gameStateRef.current.score);
        setGameState((prev) => ({ ...prev, status: 'GAME_OVER' }));
      }
      return;
    }

    if (
      gameStateRef.current.status !== 'PLAYING' ||
      isGameMenuOpen ||
      isHowToPlayOpen
    ) {
      return;
    }

    // Check pointer inputs
    const input = inputRef.current;
    if (input.actions.up) requestDirection({ x: 0, y: -1 });
    if (input.actions.down) requestDirection({ x: 0, y: 1 });
    if (input.actions.left) requestDirection({ x: -1, y: 0 });
    if (input.actions.right) requestDirection({ x: 1, y: 0 });

    // Grid Step Simulation
    const stepInterval = 1 / currentSpeedRef.current;
    stepTimerRef.current += deltaTime;

    while (stepTimerRef.current >= stepInterval) {
      stepTimerRef.current -= stepInterval;

      if (nextDirectionQueueRef.current.length > 0) {
        directionRef.current = nextDirectionQueueRef.current.shift()!;
      }

      const currentSnake = snakeRef.current;
      if (currentSnake.length === 0) return;

      prevSnakeRef.current = currentSnake.map((p) => ({ ...p }));

      const head = currentSnake[0];
      const dir = directionRef.current;
      const newHead: Point = { x: head.x + dir.x, y: head.y + dir.y };

      // 1. Collision with Walls
      if (
        newHead.x < 0 ||
        newHead.x >= gridCols ||
        newHead.y < 0 ||
        newHead.y >= gridRows
      ) {
        triggerDeath();
        return;
      }

      // 2. Collision with Obstacles
      const mapObstacles = activeObstaclesRef.current;
      const hitObstacle = mapObstacles.some(
        (obs) => obs.x === newHead.x && obs.y === newHead.y,
      );
      if (hitObstacle) {
        triggerDeath();
        return;
      }

      // 3. Collision with Self (Tail)
      const hitSelf = currentSnake.some(
        (seg, idx) => idx > 0 && seg.x === newHead.x && seg.y === newHead.y,
      );
      if (hitSelf) {
        triggerDeath();
        return;
      }

      // 4. Check Food
      const food = foodRef.current;
      const ateFood = newHead.x === food.x && newHead.y === food.y;

      const newSnake = [newHead, ...currentSnake];

      if (ateFood) {
        // Ate Frog! Realistic Croak SFX
        gameAudio.playFrogCroak();
        triggerHaptic(25);

        const pts = getConfig('pointsPerFrog') as number;
        const newScore = gameStateRef.current.score + pts;

        setGameState((prev) => ({
          ...prev,
          score: newScore,
        }));

        const speedInc = getConfig('speedIncrementPerFood') as number;
        const maxSpd = getConfig('maxSpeed') as number;
        currentSpeedRef.current = Math.min(
          maxSpd,
          currentSpeedRef.current + speedInc,
        );

        headEatScaleRef.current = 1.45;
        frogEatScaleRef.current = 1.6;

        const headPixelX = arenaOffsetX + newHead.x * tileSize + tileSize / 2;
        const headPixelY = arenaOffsetY + newHead.y * tileSize;
        floatingTextsRef.current.push({
          id: Date.now() + Math.random(),
          x: headPixelX,
          y: headPixelY,
          text: `+${pts}`,
          color: currentSkin.glow,
          alpha: 1,
          scale: 1,
          vy: -65,
        });

        // Frog splash particles
        for (let i = 0; i < 16; i++) {
          const ang = (Math.PI * 2 * i) / 16 + Math.random() * 0.4;
          const spd = 70 + Math.random() * 100;
          particlesRef.current.push({
            id: Date.now() + Math.random(),
            x: headPixelX,
            y: headPixelY + tileSize / 2,
            vx: Math.cos(ang) * spd,
            vy: Math.sin(ang) * spd,
            color: Math.random() > 0.4 ? '#4ade80' : '#facc15',
            size: 4 + Math.random() * 4,
            alpha: 1,
            maxLife: 0.5 + Math.random() * 0.3,
            life: 0,
          });
        }

        spawnFood();
      } else {
        newSnake.pop();
      }

      snakeRef.current = newSnake;
    }
  };

  const triggerDeath = () => {
    isDeadRef.current = true;
    deathTimerRef.current = 0;
    screenShakeRef.current = 14;
    gameAudio.playChiptuneExplosion();
    gameAudio.playMeleePunch();
    triggerHaptic([50, 50, 100]);

    const currentSnake = snakeRef.current;
    if (currentSnake.length > 0) {
      const head = currentSnake[0];
      const headPixelX = arenaOffsetX + head.x * tileSize + tileSize / 2;
      const headPixelY = arenaOffsetY + head.y * tileSize + tileSize / 2;

      for (let i = 0; i < 22; i++) {
        const ang = Math.random() * Math.PI * 2;
        const spd = 80 + Math.random() * 130;
        particlesRef.current.push({
          id: Date.now() + Math.random(),
          x: headPixelX,
          y: headPixelY,
          vx: Math.cos(ang) * spd,
          vy: Math.sin(ang) * spd,
          color: Math.random() > 0.5 ? '#f87171' : '#fbbf24',
          size: 5 + Math.random() * 5,
          alpha: 1,
          maxLife: 0.6 + Math.random() * 0.4,
          life: 0,
        });
      }
    }
  };

  // --- Rendering Functions ---
  const drawMapBackgroundAndBorder = (
    ctx: CanvasRenderingContext2D,
    theme: string,
    arenaX: number,
    arenaY: number,
    arenaW: number,
    arenaH: number,
  ) => {
    // 1. Draw Map Turf Backdrop
    if (theme === 'classic') {
      // Vibrant Arcade Turf with subtle checkerboard
      const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
      grad.addColorStop(0, '#0f172a');
      grad.addColorStop(1, '#020617');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      // Arena Turf
      ctx.fillStyle = '#0a2336';
      ctx.fillRect(arenaX, arenaY, arenaW, arenaH);

      // Subtle Checker Pattern
      for (let c = 0; c < gridCols; c++) {
        for (let r = 0; r < gridRows; r++) {
          if ((c + r) % 2 === 0) {
            ctx.fillStyle = 'rgba(56, 189, 248, 0.04)';
            ctx.fillRect(
              arenaX + c * tileSize,
              arenaY + r * tileSize,
              tileSize,
              tileSize,
            );
          }
        }
      }

      // Rounded 3D Border with Neon Rim
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#0284c7';
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 10;
      ctx.strokeRect(arenaX, arenaY, arenaW, arenaH);
      ctx.shadowBlur = 0;
    } else if (theme === 'forest') {
      // Lush Forest Floor
      const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
      grad.addColorStop(0, '#052e16');
      grad.addColorStop(1, '#022c22');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      ctx.fillStyle = '#064e3b';
      ctx.fillRect(arenaX, arenaY, arenaW, arenaH);

      // Leaf speckles
      for (let c = 0; c < gridCols; c++) {
        for (let r = 0; r < gridRows; r++) {
          if ((c * 7 + r * 13) % 5 === 0) {
            ctx.fillStyle = 'rgba(74, 222, 128, 0.07)';
            ctx.beginPath();
            ctx.arc(
              arenaX + c * tileSize + tileSize * 0.5,
              arenaY + r * tileSize + tileSize * 0.5,
              tileSize * 0.3,
              0,
              Math.PI * 2,
            );
            ctx.fill();
          }
        }
      }

      // Wood canopy border with leafy corners
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#15803d';
      ctx.shadowColor = '#4ade80';
      ctx.shadowBlur = 8;
      ctx.strokeRect(arenaX, arenaY, arenaW, arenaH);
      ctx.shadowBlur = 0;
    } else if (theme === 'desert') {
      // Sandstone tiles
      const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
      grad.addColorStop(0, '#451a03');
      grad.addColorStop(1, '#291002');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      ctx.fillStyle = '#78350f';
      ctx.fillRect(arenaX, arenaY, arenaW, arenaH);

      // Warm Sandstone tile highlights
      for (let c = 0; c < gridCols; c++) {
        for (let r = 0; r < gridRows; r++) {
          if ((c + r) % 2 === 0) {
            ctx.fillStyle = 'rgba(251, 191, 36, 0.05)';
            ctx.fillRect(
              arenaX + c * tileSize + 1,
              arenaY + r * tileSize + 1,
              tileSize - 2,
              tileSize - 2,
            );
          }
        }
      }

      // Desert Border
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#b45309';
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = 8;
      ctx.strokeRect(arenaX, arenaY, arenaW, arenaH);
      ctx.shadowBlur = 0;
    } else if (theme === 'ice') {
      // Crystalline Ice
      const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
      grad.addColorStop(0, '#082f49');
      grad.addColorStop(1, '#0c4a6e');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      ctx.fillStyle = '#075985';
      ctx.fillRect(arenaX, arenaY, arenaW, arenaH);

      // Translucent Ice cracks & shimmer
      for (let c = 0; c < gridCols; c++) {
        for (let r = 0; r < gridRows; r++) {
          if ((c * 3 + r * 5) % 4 === 0) {
            ctx.fillStyle = 'rgba(224, 242, 254, 0.08)';
            ctx.fillRect(
              arenaX + c * tileSize + 2,
              arenaY + r * tileSize + 2,
              tileSize - 4,
              tileSize - 4,
            );
          }
        }
      }

      // Frosted ice trim
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#38bdf8';
      ctx.shadowColor = '#bae6fd';
      ctx.shadowBlur = 10;
      ctx.strokeRect(arenaX, arenaY, arenaW, arenaH);
      ctx.shadowBlur = 0;
    } else {
      // Night Neon bioluminescent
      const grad = ctx.createLinearGradient(0, 0, 0, canvasHeight);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(1, '#0f0e2a');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasWidth, canvasHeight);

      ctx.fillStyle = '#2e1065';
      ctx.fillRect(arenaX, arenaY, arenaW, arenaH);

      // Fireflies floating
      for (const ff of firefliesRef.current) {
        const glowAlpha = 0.3 + 0.7 * Math.sin(ff.phase);
        ctx.fillStyle = `rgba(192, 132, 252, ${glowAlpha})`;
        ctx.beginPath();
        ctx.arc(ff.x, ff.y, ff.size, 0, Math.PI * 2);
        ctx.fill();
      }

      // Glowing Neon border
      ctx.lineWidth = 6;
      ctx.strokeStyle = '#a855f7';
      ctx.shadowColor = '#c084fc';
      ctx.shadowBlur = 12;
      ctx.strokeRect(arenaX, arenaY, arenaW, arenaH);
      ctx.shadowBlur = 0;
    }

    // Grid guide lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.035)';
    ctx.lineWidth = 1;
    for (let c = 1; c < gridCols; c++) {
      const gx = arenaX + c * tileSize;
      ctx.beginPath();
      ctx.moveTo(gx, arenaY);
      ctx.lineTo(gx, arenaY + arenaH);
      ctx.stroke();
    }
    for (let r = 1; r < gridRows; r++) {
      const gy = arenaY + r * tileSize;
      ctx.beginPath();
      ctx.moveTo(arenaX, gy);
      ctx.lineTo(arenaX + arenaW, gy);
      ctx.stroke();
    }
  };

  // Render Cute Cartoon Frog Food
  const drawCartoonFrog = (
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    size: number,
  ) => {
    const hop = Math.sin(frogHopTimerRef.current) * 3;
    const pulse = 1 + Math.sin(frogHopTimerRef.current * 0.8) * 0.04;
    const scale = frogEatScaleRef.current * pulse;

    ctx.save();
    ctx.translate(x + size / 2, y + size / 2 + hop);
    ctx.scale(scale, scale);

    const rad = size * 0.42;

    // Drop shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, rad * 0.9 - hop, rad * 1.1, rad * 0.45, 0, 0, Math.PI * 2);
    ctx.fill();

    // Cute folded hind legs
    ctx.fillStyle = '#15803d';
    ctx.strokeStyle = '#052e16';
    ctx.lineWidth = 2.5;

    // Left leg
    ctx.beginPath();
    ctx.ellipse(-rad * 0.85, rad * 0.4, rad * 0.4, rad * 0.25, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Right leg
    ctx.beginPath();
    ctx.ellipse(rad * 0.85, rad * 0.4, rad * 0.4, rad * 0.25, 0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Main rounded green body
    const bodyGrad = ctx.createRadialGradient(
      -rad * 0.2,
      -rad * 0.2,
      rad * 0.1,
      0,
      0,
      rad,
    );
    bodyGrad.addColorStop(0, '#86efac');
    bodyGrad.addColorStop(0.6, '#22c55e');
    bodyGrad.addColorStop(1, '#16a34a');

    ctx.fillStyle = bodyGrad;
    ctx.beginPath();
    ctx.ellipse(0, rad * 0.1, rad * 0.9, rad * 0.8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Cute spots on frog back
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.arc(-rad * 0.3, rad * 0.2, rad * 0.14, 0, Math.PI * 2);
    ctx.arc(rad * 0.35, rad * 0.25, rad * 0.12, 0, Math.PI * 2);
    ctx.arc(0, rad * 0.45, rad * 0.1, 0, Math.PI * 2);
    ctx.fill();

    // Big bulging frog eye sockets on top
    const eyeRadius = rad * 0.38;
    const eyeOffsetX = rad * 0.48;
    const eyeOffsetY = -rad * 0.45;

    // Left Eye Socket
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.arc(-eyeOffsetX, eyeOffsetY, eyeRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Right Eye Socket
    ctx.beginPath();
    ctx.arc(eyeOffsetX, eyeOffsetY, eyeRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Eye Whites
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-eyeOffsetX, eyeOffsetY, eyeRadius * 0.75, 0, Math.PI * 2);
    ctx.arc(eyeOffsetX, eyeOffsetY, eyeRadius * 0.75, 0, Math.PI * 2);
    ctx.fill();

    // Black Pupils
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(-eyeOffsetX, eyeOffsetY - 1, eyeRadius * 0.45, 0, Math.PI * 2);
    ctx.arc(eyeOffsetX, eyeOffsetY - 1, eyeRadius * 0.45, 0, Math.PI * 2);
    ctx.fill();

    // Glossy Highlights
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(-eyeOffsetX + 1.5, eyeOffsetY - 2.5, eyeRadius * 0.2, 0, Math.PI * 2);
    ctx.arc(eyeOffsetX + 1.5, eyeOffsetY - 2.5, eyeRadius * 0.2, 0, Math.PI * 2);
    ctx.fill();

    // Cute smiling mouth / blush
    ctx.strokeStyle = '#14532d';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, rad * 0.05, rad * 0.4, 0.2, Math.PI - 0.2);
    ctx.stroke();

    // Rosy cheeks
    ctx.fillStyle = 'rgba(244, 63, 94, 0.4)';
    ctx.beginPath();
    ctx.arc(-rad * 0.48, rad * 0.15, rad * 0.12, 0, Math.PI * 2);
    ctx.arc(rad * 0.48, rad * 0.15, rad * 0.12, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  };

  // Render Redesigned Cartoon Snake (Volumetric body, Expressive head & skin tinting)
  const drawCartoonSnake = (
    ctx: CanvasRenderingContext2D,
    interpSnake: Point[],
    skin: SnakeSkin,
  ) => {
    if (interpSnake.length === 0) return;

    // 1. Draw Body Segments (tail to neck for depth layering)
    for (let i = interpSnake.length - 1; i >= 1; i--) {
      const seg = interpSnake[i];
      const nextSeg = interpSnake[i - 1];
      const segRatio = (interpSnake.length - i) / interpSnake.length;
      const baseRadius = (tileSize / 2) * (0.65 + segRatio * 0.35);
      const radius = Math.max(5, baseRadius);

      // Drop shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.beginPath();
      ctx.ellipse(seg.x, seg.y + 4, radius, radius * 0.7, 0, 0, Math.PI * 2);
      ctx.fill();

      // Connecting segment spine for seamless snake look
      if (nextSeg) {
        ctx.strokeStyle = skin.secondary;
        ctx.lineWidth = radius * 1.8;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(seg.x, seg.y);
        ctx.lineTo(nextSeg.x, nextSeg.y);
        ctx.stroke();

        ctx.strokeStyle = skin.primary;
        ctx.lineWidth = radius * 1.4;
        ctx.beginPath();
        ctx.moveTo(seg.x, seg.y);
        ctx.lineTo(nextSeg.x, nextSeg.y);
        ctx.stroke();
      }

      // Outer outline & spherical gradient
      const sphereGrad = ctx.createRadialGradient(
        seg.x - radius * 0.3,
        seg.y - radius * 0.3,
        radius * 0.1,
        seg.x,
        seg.y,
        radius,
      );
      sphereGrad.addColorStop(0, skin.glow);
      sphereGrad.addColorStop(0.5, skin.primary);
      sphereGrad.addColorStop(1, skin.secondary);

      ctx.fillStyle = sphereGrad;
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(seg.x, seg.y, radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Volumetric glossy highlight sheen
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.beginPath();
      ctx.ellipse(
        seg.x - radius * 0.3,
        seg.y - radius * 0.3,
        radius * 0.35,
        radius * 0.2,
        -0.5,
        0,
        Math.PI * 2,
      );
      ctx.fill();
    }

    // 2. Draw Snake Head
    const head = interpSnake[0];
    const headRadius = (tileSize / 2) * 1.15 * headEatScaleRef.current;

    const dir = directionRef.current;
    let headAngle = 0;
    if (dir.x === 1) headAngle = 0;
    else if (dir.x === -1) headAngle = Math.PI;
    else if (dir.y === 1) headAngle = Math.PI / 2;
    else if (dir.y === -1) headAngle = -Math.PI / 2;

    ctx.save();
    ctx.translate(head.x, head.y);
    ctx.rotate(headAngle);

    // Head Drop Shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(0, 6, headRadius * 1.1, headRadius * 0.8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Flicking Forked Tongue
    const tongueFlick = Math.sin(tongueTimerRef.current * 4);
    if (tongueFlick > 0.2) {
      const tLen = headRadius * (0.8 + tongueFlick * 0.5);
      ctx.strokeStyle = '#f43f5e';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(headRadius * 0.8, 0);
      ctx.lineTo(headRadius * 0.8 + tLen, 0);
      ctx.lineTo(headRadius * 0.8 + tLen + 5, -4);
      ctx.moveTo(headRadius * 0.8 + tLen, 0);
      ctx.lineTo(headRadius * 0.8 + tLen + 5, 4);
      ctx.stroke();
    }

    // Main Cartoon Snake Head Shape
    const headGrad = ctx.createRadialGradient(
      headRadius * 0.2,
      -headRadius * 0.2,
      headRadius * 0.2,
      0,
      0,
      headRadius * 1.1,
    );
    headGrad.addColorStop(0, skin.glow);
    headGrad.addColorStop(0.5, skin.primary);
    headGrad.addColorStop(1, skin.secondary);

    ctx.fillStyle = headGrad;
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.lineWidth = 2.5;

    ctx.beginPath();
    ctx.ellipse(
      headRadius * 0.1,
      0,
      headRadius * 1.05,
      headRadius * 0.9,
      0,
      0,
      Math.PI * 2,
    );
    ctx.fill();
    ctx.stroke();

    // Cute Snout & Nostrils
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.arc(headRadius * 0.75, -headRadius * 0.18, headRadius * 0.08, 0, Math.PI * 2);
    ctx.arc(headRadius * 0.75, headRadius * 0.18, headRadius * 0.08, 0, Math.PI * 2);
    ctx.fill();

    // Expressive Big Cartoon Eyes
    const eyeSize = headRadius * 0.38;
    const eyeX = headRadius * 0.25;
    const eyeY = headRadius * 0.46;

    // Eye sockets
    ctx.fillStyle = skin.secondary;
    ctx.beginPath();
    ctx.arc(eyeX, -eyeY, eyeSize * 1.1, 0, Math.PI * 2);
    ctx.arc(eyeX, eyeY, eyeSize * 1.1, 0, Math.PI * 2);
    ctx.fill();

    // Eye Whites
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.arc(eyeX, -eyeY, eyeSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(eyeX, eyeY, eyeSize, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    // Dark Pupils (tracking direction + cute glance)
    const pupilX = eyeX + eyeSize * 0.3;
    ctx.fillStyle = '#090d16';
    ctx.beginPath();
    ctx.arc(pupilX, -eyeY, eyeSize * 0.52, 0, Math.PI * 2);
    ctx.arc(pupilX, eyeY, eyeSize * 0.52, 0, Math.PI * 2);
    ctx.fill();

    // Crisp Glossy Eye Highlights
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(pupilX + 1, -eyeY - 2, eyeSize * 0.22, 0, Math.PI * 2);
    ctx.arc(pupilX + 1, eyeY - 2, eyeSize * 0.22, 0, Math.PI * 2);
    ctx.fill();

    // Head Sheen
    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.beginPath();
    ctx.ellipse(
      -headRadius * 0.2,
      -headRadius * 0.2,
      headRadius * 0.45,
      headRadius * 0.2,
      -0.4,
      0,
      Math.PI * 2,
    );
    ctx.fill();

    ctx.restore();

    // Dizzy Stars when Crashed
    if (isDeadRef.current) {
      const starImg = assets['dizzy_star'];
      const starCount = 4;
      const orbitRadius = tileSize * 1.1;

      for (let i = 0; i < starCount; i++) {
        const angle = dizzyAngleRef.current + (i * Math.PI * 2) / starCount;
        const sx = head.x + Math.cos(angle) * orbitRadius;
        const sy = head.y + Math.sin(angle) * (orbitRadius * 0.55) - 12;

        ctx.save();
        ctx.translate(sx, sy);
        ctx.rotate(angle * 2.5);

        if (starImg && starImg.complete && starImg.naturalWidth > 0) {
          ctx.drawImage(starImg, -14, -14, 28, 28);
        } else {
          ctx.fillStyle = '#facc15';
          ctx.strokeStyle = '#ca8a04';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(0, 0, 9, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
        }
        ctx.restore();
      }
    }
  };

  // --- Rendering Loop ---
  const draw = (ctx: CanvasRenderingContext2D) => {
    prepareCanvas(ctx, canvasWidth, canvasHeight);

    ctx.save();
    if (screenShakeRef.current > 0) {
      const sx = (Math.random() - 0.5) * screenShakeRef.current;
      const sy = (Math.random() - 0.5) * screenShakeRef.current;
      ctx.translate(sx, sy);
    }

    const arenaW = gridCols * tileSize;
    const arenaH = gridRows * tileSize;

    // 1. Draw Map Environment & Border
    drawMapBackgroundAndBorder(
      ctx,
      currentMap.theme,
      arenaOffsetX,
      arenaOffsetY,
      arenaW,
      arenaH,
    );

    // 2. Draw Obstacles
    const mapObstacles = activeObstaclesRef.current;
    for (const obs of mapObstacles) {
      const ox = arenaOffsetX + obs.x * tileSize;
      const oy = arenaOffsetY + obs.y * tileSize;

      if (currentMap.obstacleType === 'rock') {
        drawAsset(
          ctx,
          assets['obstacle_rock'],
          ox,
          oy,
          tileSize,
          tileSize,
          (fCtx) => {
            fCtx.fillStyle = '#78350f';
            fCtx.strokeStyle = '#451a03';
            fCtx.lineWidth = 3;
            fCtx.beginPath();
            fCtx.arc(
              ox + tileSize / 2,
              oy + tileSize / 2,
              tileSize / 2 - 3,
              0,
              Math.PI * 2,
            );
            fCtx.fill();
            fCtx.stroke();
          },
        );
      } else if (currentMap.obstacleType === 'ice') {
        drawAsset(
          ctx,
          assets['obstacle_ice_block'],
          ox,
          oy,
          tileSize,
          tileSize,
          (fCtx) => {
            fCtx.fillStyle = 'rgba(56, 189, 248, 0.7)';
            fCtx.strokeStyle = '#bae6fd';
            fCtx.lineWidth = 3;
            fCtx.fillRect(ox + 3, oy + 3, tileSize - 6, tileSize - 6);
            fCtx.strokeRect(ox + 3, oy + 3, tileSize - 6, tileSize - 6);
          },
        );
      } else if (currentMap.obstacleType === 'night_crystal') {
        ctx.fillStyle = '#a855f7';
        ctx.shadowColor = '#c084fc';
        ctx.shadowBlur = 8;
        ctx.fillRect(ox + 4, oy + 4, tileSize - 8, tileSize - 8);
        ctx.shadowBlur = 0;
      }
    }

    // 3. Draw Cartoon Frog
    const food = foodRef.current;
    if (food) {
      const fx = arenaOffsetX + food.x * tileSize;
      const fy = arenaOffsetY + food.y * tileSize;
      drawCartoonFrog(ctx, fx, fy, tileSize);
    }

    // 4. Draw Smooth Interpolated Cartoon Snake
    const currentSnake = snakeRef.current;
    const prevSnake = prevSnakeRef.current;
    const stepInterval = 1 / currentSpeedRef.current;
    const stepFraction = Math.min(
      1,
      Math.max(0, stepTimerRef.current / stepInterval),
    );

    if (currentSnake.length > 0) {
      const interpSnake: Point[] = [];
      for (let i = 0; i < currentSnake.length; i++) {
        const cur = currentSnake[i];
        const prev = prevSnake[i] || cur;
        const px =
          arenaOffsetX +
          (prev.x + (cur.x - prev.x) * stepFraction) * tileSize +
          tileSize / 2;
        const py =
          arenaOffsetY +
          (prev.y + (cur.y - prev.y) * stepFraction) * tileSize +
          tileSize / 2;
        interpSnake.push({ x: px, y: py });
      }

      drawCartoonSnake(ctx, interpSnake, currentSkin);
    }

    // 5. Draw Particles
    for (const p of particlesRef.current) {
      ctx.save();
      ctx.globalAlpha = p.alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, Math.max(1, p.size), 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // 6. Draw Floating Score Texts
    for (const ft of floatingTextsRef.current) {
      ctx.save();
      ctx.globalAlpha = ft.alpha;
      ctx.font = `900 ${Math.floor(24 * ft.scale)}px "Segoe UI", Roboto, sans-serif`;
      ctx.fillStyle = ft.color;
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 4;
      ctx.textAlign = 'center';
      ctx.strokeText(ft.text, ft.x, ft.y);
      ctx.fillText(ft.text, ft.x, ft.y);
      ctx.restore();
    }

    ctx.restore();
  };

  // --- Game Loop Hooks ---
  const updateRef = useRef(update);
  const drawRef = useRef(draw);
  updateRef.current = update;
  drawRef.current = draw;

  useEffect(() => {
    let raf = 0;
    const loop = (time: number) => {
      if (inputRef.current) {
        const cancelPressed = inputRef.current.actions.cancel;
        if (cancelPressed && !lastCancelRef.current) {
          const currentStatus = gameStateRef.current.status;
          if (currentStatus === 'PLAYING') {
            setIsGameMenuOpen((prev) => !prev);
          } else if (currentStatus === 'START') {
            void exitChat({});
          } else if (
            ['GAME_OVER', 'VICTORY', 'LEVEL_COMPLETE'].includes(currentStatus)
          ) {
            setGameState((prev) => ({ ...prev, status: 'START' }));
          }
        }
        lastCancelRef.current = cancelPressed;
      }

      stepperRef.current?.(time, (dt) => updateRef.current(dt));

      const ctx = canvasRef.current?.getContext('2d');
      if (ctx) drawRef.current(ctx);

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [exitChat]);

  // Autofocus buttons
  const startBtnRef = useAutoFocus<HTMLButtonElement>(
    gameState.status === 'START',
  );
  const tryAgainBtnRef = useAutoFocus<HTMLButtonElement>(
    gameState.status === 'GAME_OVER',
  );

  return (
    <div
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      className="fixed inset-0 overflow-hidden touch-none flex flex-col items-center justify-between bg-slate-950 text-white font-sans select-none">
      {/* --- POLISHED CARTOON ARCADE LOADING SCREEN --- */}
      {isLoaderMounted && (
        <div
          className={`absolute inset-0 z-50 flex flex-col items-center justify-between p-6 overflow-hidden bg-gradient-to-b from-[#060b17] via-[#091322] to-[#030710] text-white select-none transition-all duration-500 ${
            loadingFadingOut ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
          }`}>
          <style>{`
            @keyframes snake-ring-spin {
              0% { transform: rotate(0deg); }
              100% { transform: rotate(360deg); }
            }
            @keyframes tongue-flick {
              0%, 100% { transform: scaleX(0.2) scaleY(0.8); opacity: 0.2; }
              40% { transform: scaleX(1.1) scaleY(1); opacity: 1; }
              70% { transform: scaleX(0.9) scaleY(1); opacity: 1; }
            }
            @keyframes frog-float {
              0%, 100% { transform: translateY(0) scale(1); }
              50% { transform: translateY(-5px) scale(1.05); }
            }
            @keyframes neon-shimmer {
              0% { transform: translateX(-100%); }
              100% { transform: translateX(200%); }
            }
            @keyframes dot-bounce {
              0%, 80%, 100% { transform: translateY(0); opacity: 0.4; }
              40% { transform: translateY(-6px); opacity: 1; color: #38bdf8; }
            }
            @keyframes spark-float {
              0% { transform: translateY(0) translateX(0); opacity: 0.2; }
              50% { transform: translateY(-40px) translateX(15px); opacity: 0.9; }
              100% { transform: translateY(-90px) translateX(-10px); opacity: 0; }
            }
            @keyframes grid-pulse {
              0%, 100% { opacity: 0.12; }
              50% { opacity: 0.25; }
            }
            .anim-snake-spin {
              transform-origin: 80px 80px;
              animation: snake-ring-spin 2.4s linear infinite;
            }
            .anim-tongue {
              transform-origin: 10px 0px;
              animation: tongue-flick 0.8s ease-in-out infinite;
            }
            .anim-frog {
              animation: frog-float 1.8s ease-in-out infinite;
            }
            .anim-shimmer {
              animation: neon-shimmer 1.8s linear infinite;
            }
            .dot-1 { animation: dot-bounce 1.2s infinite ease-in-out; }
            .dot-2 { animation: dot-bounce 1.2s infinite ease-in-out 0.2s; }
            .dot-3 { animation: dot-bounce 1.2s infinite ease-in-out 0.4s; }
          `}</style>

          {/* Background Neon Grid / Ambient Glow */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            {/* Hex / Grid overlay */}
            <div
              className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] [animation:grid-pulse_4s_ease-in-out_infinite]"
            />
            {/* Ambient colored glowing orbs */}
            <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-96 h-96 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute bottom-10 left-1/4 w-72 h-72 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute top-1/3 right-10 w-60 h-60 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

            {/* Floating Sparks */}
            <div
              className="absolute bottom-20 left-[15%] w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]"
              style={{ animation: 'spark-float 3.5s infinite linear' }}
            />
            <div
              className="absolute bottom-32 left-[40%] w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#38bdf8]"
              style={{ animation: 'spark-float 4.2s infinite linear 0.7s' }}
            />
            <div
              className="absolute bottom-16 right-[25%] w-2 h-2 rounded-full bg-yellow-400 shadow-[0_0_8px_#facc15]"
              style={{ animation: 'spark-float 3.8s infinite linear 1.4s' }}
            />
            <div
              className="absolute bottom-40 right-[15%] w-1.5 h-1.5 rounded-full bg-emerald-300 shadow-[0_0_8px_#6ee7b7]"
              style={{ animation: 'spark-float 4.5s infinite linear 2.1s' }}
            />
            <div
              className="absolute bottom-28 left-[65%] w-2.5 h-2.5 rounded-full bg-teal-300 shadow-[0_0_10px_#5eead4]"
              style={{ animation: 'spark-float 3.2s infinite linear 1.1s' }}
            />
          </div>

          {/* TOP: Empty spacer for balanced flex layout */}
          <div className="h-4 w-full" />

          {/* CENTER: Main Title & Looping Animated Snake */}
          <div className="relative z-10 flex flex-col items-center max-w-sm w-full my-auto">
            {/* Title Header with Glowing Bevels */}
            <div className="flex flex-col items-center mb-6">
              <div className="flex items-center gap-1.5 px-3 py-1 mb-3 rounded-full bg-emerald-950/60 border border-emerald-500/40 text-[11px] font-black tracking-widest text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
                <Sparkles size={12} className="text-yellow-400 fill-current animate-pulse" />
                <span>RETRO CARTOON ARCADE</span>
                <Sparkles size={12} className="text-yellow-400 fill-current animate-pulse" />
              </div>

              <div className="relative flex items-center justify-center gap-2">
                <h1 className="text-4xl sm:text-5xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 via-teal-200 to-cyan-300 drop-shadow-[0_4px_12px_rgba(16,185,129,0.7)] filter">
                  SNAKE
                </h1>
                <div className="px-2.5 py-1 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 text-slate-950 font-black text-2xl sm:text-3xl tracking-tight shadow-[0_0_16px_rgba(6,182,212,0.8)] border border-cyan-200/80 -rotate-2">
                  26s
                </div>
              </div>
            </div>

            {/* ANIMATED LOOPING CARTOON SNAKE RING SPINNER */}
            <div className="relative w-44 h-44 sm:w-48 sm:h-48 flex items-center justify-center mb-6">
              {/* Outer Glow Halo */}
              <div className="absolute inset-2 rounded-full bg-emerald-500/10 blur-xl animate-pulse" />

              <svg
                viewBox="0 0 160 160"
                className="w-full h-full drop-shadow-[0_0_14px_rgba(16,185,129,0.5)]"
                style={{ overflow: 'visible' }}>
                <defs>
                  {/* Glowing Track Gradients */}
                  <linearGradient id="ringTrackGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#10b981" stopOpacity="0.25" />
                    <stop offset="50%" stopColor="#06b6d4" stopOpacity="0.35" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.15" />
                  </linearGradient>

                  {/* Snake Head Gradient */}
                  <radialGradient id="snakeHeadGrad" cx="30%" cy="30%" r="70%">
                    <stop offset="0%" stopColor="#86efac" />
                    <stop offset="45%" stopColor="#22c55e" />
                    <stop offset="100%" stopColor="#15803d" />
                  </radialGradient>

                  {/* Snake Body Segment Gradient */}
                  <radialGradient id="snakeBodyGrad" cx="30%" cy="30%" r="70%">
                    <stop offset="0%" stopColor="#67e8f9" />
                    <stop offset="50%" stopColor="#06b6d4" />
                    <stop offset="100%" stopColor="#0369a1" />
                  </radialGradient>

                  {/* Frog Body Gradient */}
                  <radialGradient id="frogLoaderGrad" cx="35%" cy="35%" r="65%">
                    <stop offset="0%" stopColor="#fef08a" />
                    <stop offset="40%" stopColor="#eab308" />
                    <stop offset="100%" stopColor="#ca8a04" />
                  </radialGradient>
                </defs>

                {/* Ring Track Background */}
                <circle
                  cx="80"
                  cy="80"
                  r="54"
                  fill="none"
                  stroke="url(#ringTrackGrad)"
                  strokeWidth="8"
                  strokeLinecap="round"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="54"
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeDasharray="4 8"
                  opacity="0.5"
                />

                {/* Center Bouncing Cartoon Frog Target */}
                <g className="anim-frog" transform="translate(80, 80)">
                  {/* Frog Drop Shadow */}
                  <ellipse cx="0" cy="14" rx="14" ry="4" fill="rgba(0,0,0,0.3)" />

                  {/* Frog Golden Body */}
                  <ellipse cx="0" cy="2" rx="15" ry="12" fill="url(#frogLoaderGrad)" stroke="#a16207" strokeWidth="1.5" />

                  {/* Frog Eye Sockets */}
                  <circle cx="-6" cy="-8" r="5" fill="#eab308" stroke="#a16207" strokeWidth="1.5" />
                  <circle cx="6" cy="-8" r="5" fill="#eab308" stroke="#a16207" strokeWidth="1.5" />

                  {/* Eye Whites */}
                  <circle cx="-6" cy="-8" r="3.5" fill="#ffffff" />
                  <circle cx="6" cy="-8" r="3.5" fill="#ffffff" />

                  {/* Pupils */}
                  <circle cx="-5" cy="-8" r="2" fill="#0f172a" />
                  <circle cx="7" cy="-8" r="2" fill="#0f172a" />

                  {/* Highlights */}
                  <circle cx="-4.5" cy="-9" r="0.8" fill="#ffffff" />
                  <circle cx="7.5" cy="-9" r="0.8" fill="#ffffff" />

                  {/* Cute Smile */}
                  <path d="M -4 4 Q 0 7 4 4" fill="none" stroke="#713f12" strokeWidth="1.5" strokeLinecap="round" />
                </g>

                {/* CONTINUOUS ROTATING SNAKE GROUP */}
                <g className="anim-snake-spin">
                  {/* Segment 6 (Tail tip) */}
                  <circle cx="80" cy="26" r="4.5" fill="#0284c7" stroke="#082f49" strokeWidth="1" transform="rotate(-90 80 80)" />

                  {/* Segment 5 */}
                  <circle cx="80" cy="26" r="6" fill="#06b6d4" stroke="#0e7490" strokeWidth="1" transform="rotate(-72 80 80)" />

                  {/* Segment 4 */}
                  <circle cx="80" cy="26" r="7.5" fill="#22d3ee" stroke="#0891b2" strokeWidth="1.2" transform="rotate(-54 80 80)" />

                  {/* Segment 3 */}
                  <circle cx="80" cy="26" r="9" fill="#34d399" stroke="#059669" strokeWidth="1.5" transform="rotate(-36 80 80)" />

                  {/* Segment 2 (Neck) */}
                  <circle cx="80" cy="26" r="10.5" fill="#4ade80" stroke="#16a34a" strokeWidth="1.5" transform="rotate(-18 80 80)" />

                  {/* SNAKE HEAD AT 0 DEG (Top Leading Edge) */}
                  <g transform="translate(80, 26)">
                    {/* Head Main Oval */}
                    <ellipse cx="0" cy="0" rx="14" ry="12" fill="url(#snakeHeadGrad)" stroke="#14532d" strokeWidth="1.8" />

                    {/* Flicking Forked Tongue */}
                    <g className="anim-tongue" transform="translate(13, 0)">
                      <path
                        d="M 0 0 L 8 0 M 8 0 L 12 -3 M 8 0 L 12 3"
                        fill="none"
                        stroke="#f43f5e"
                        strokeWidth="1.8"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </g>

                    {/* Left Eye */}
                    <circle cx="3" cy="-7" r="4.5" fill="#ffffff" stroke="#0f172a" strokeWidth="1.2" />
                    <circle cx="4.5" cy="-7" r="2.4" fill="#0f172a" />
                    <circle cx="5" cy="-8" r="1" fill="#ffffff" />

                    {/* Right Eye */}
                    <circle cx="3" cy="7" r="4.5" fill="#ffffff" stroke="#0f172a" strokeWidth="1.2" />
                    <circle cx="4.5" cy="7" r="2.4" fill="#0f172a" />
                    <circle cx="5" cy="6" r="1" fill="#ffffff" />

                    {/* Nostrils */}
                    <circle cx="10" cy="-2" r="0.8" fill="#14532d" />
                    <circle cx="10" cy="2" r="0.8" fill="#14532d" />

                    {/* Volumetric Sheen */}
                    <ellipse cx="-4" cy="-4" rx="4" ry="2" fill="rgba(255,255,255,0.4)" transform="rotate(-20 -4 -4)" />
                  </g>
                </g>
              </svg>
            </div>

            {/* STATUS & ANIMATED BOUNCING LOADING DOTS */}
            <div className="flex flex-col items-center w-full">
              <div className="flex items-center gap-1.5 text-base font-black tracking-widest text-emerald-400 mb-1 drop-shadow-[0_0_8px_rgba(16,185,129,0.5)]">
                <span>LOADING</span>
                <span className="dot-1 font-black text-lg">.</span>
                <span className="dot-2 font-black text-lg">.</span>
                <span className="dot-3 font-black text-lg">.</span>
              </div>

              <div className="text-[11px] font-semibold text-slate-400 mb-3 tracking-wide">
                {displayProgress < 0.35
                  ? 'Initializing Arcade Canvas...'
                  : displayProgress < 0.7
                  ? 'Polishing Emerald Snake Scales...'
                  : displayProgress < 0.95
                  ? 'Catching Bouncy Gold Frogs...'
                  : 'Ready to Slither!'}
              </div>

              {/* Glowing Arcade Progress Bar */}
              <div className="w-64 sm:w-72 h-4 bg-slate-900/90 border-2 border-emerald-500/50 rounded-full p-0.5 shadow-[0_0_16px_rgba(16,185,129,0.3)] overflow-hidden relative">
                {/* Progress Fill */}
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 shadow-[0_0_12px_rgba(56,189,248,0.8)] transition-all duration-200 relative overflow-hidden"
                  style={{
                    width: `${Math.max(8, Math.min(100, Math.round(displayProgress * 100)))}%`,
                  }}>
                  {/* Laser Shimmer Sweep */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/50 to-transparent w-16 anim-shimmer" />
                </div>
              </div>

              {/* Progress Percentage Badge */}
              <div className="mt-2 text-xs font-black text-cyan-300 font-mono tracking-wider">
                {Math.min(100, Math.round(displayProgress * 100))}%
              </div>
            </div>
          </div>

          {/* BOTTOM FOOTER */}
          <div className="relative z-10 text-[11px] text-slate-500 font-medium tracking-wider flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Mobile Ready • Touch Swipe &amp; D-Pad Controls</span>
          </div>
        </div>
      )}

      {/* Background Music Player - Single BGM Source */}
      <BackgroundMusic
        url={BACKGROUND_MUSIC_URL}
        isPlaying={
          gameState.status === 'PLAYING' &&
          !isGameMenuOpen &&
          !isHowToPlayOpen
        }
        volume={(getConfig('defaultMusicVolume') as number) || 0.35}
        isMuted={isMusicMuted}
      />

      {/* --- COMPACT TOP HUD BAR --- */}
      <header className="w-full flex items-center justify-between px-3 md:px-5 py-1.5 bg-slate-900/95 border-b border-slate-800 shrink-0 z-20 shadow-md">
        {/* Left: Score & Map Best */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-slate-800/90 px-2.5 py-1 rounded-lg border border-slate-700">
            <Trophy size={16} className="text-yellow-400" />
            <span className="text-xs text-slate-300 font-bold">Score:</span>
            <span className="text-base font-black text-white">
              {gameState.score}
            </span>
          </div>

          <div className="hidden xs:flex items-center gap-1 bg-slate-800/70 px-2 py-1 rounded-lg border border-slate-700/80 text-xs">
            <span className="text-slate-400">Best:</span>
            <span className="font-bold text-yellow-400">
              {highScores[currentMap.id] || 0}
            </span>
          </div>
        </div>

        {/* Center: Map & Speed Badge */}
        <div className="flex items-center gap-1.5">
          <span
            className="text-xs font-bold px-2 py-0.5 rounded-full border shadow-sm"
            style={{
              borderColor: currentMap.accentColor,
              color: currentMap.accentColor,
              backgroundColor: 'rgba(0,0,0,0.4)',
            }}>
            {currentMap.name}
          </span>
          <span
            className="text-[10px] font-bold px-1.5 py-0.5 rounded-full border shadow-sm flex items-center gap-0.5"
            style={{
              borderColor: currentSpeedConfig.color,
              color: currentSpeedConfig.color,
              backgroundColor: 'rgba(0,0,0,0.4)',
            }}>
            <Zap size={10} className="fill-current" />
            {currentSpeedConfig.label}
          </span>
        </div>

        {/* Right: Quick Music, SFX & Menu Controls */}
        <div className="flex items-center gap-1.5">
          {/* Quick Music Toggle */}
          <button
            onClick={handleToggleMusic}
            title={isMusicMuted ? 'Unmute Music' : 'Mute Music'}
            className={`min-w-[36px] min-h-[36px] w-9 h-9 flex items-center justify-center rounded-lg border transition active:scale-90 ${
              isMusicMuted
                ? 'bg-rose-950/60 border-rose-800 text-rose-400'
                : 'bg-slate-800 border-slate-700 text-emerald-400 hover:bg-slate-700'
            }`}>
            <Music size={16} />
          </button>

          {/* Quick SFX Toggle */}
          <button
            onClick={handleToggleSfx}
            title={isSfxMuted ? 'Unmute Sound' : 'Mute Sound'}
            className={`min-w-[36px] min-h-[36px] w-9 h-9 flex items-center justify-center rounded-lg border transition active:scale-90 ${
              isSfxMuted
                ? 'bg-rose-950/60 border-rose-800 text-rose-400'
                : 'bg-slate-800 border-slate-700 text-emerald-400 hover:bg-slate-700'
            }`}>
            {isSfxMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
          </button>

          {/* Menu Button */}
          <button
            onClick={() => {
              gameAudio.playCrispClick();
              setIsGameMenuOpen((prev) => !prev);
            }}
            data-testid="menu-button"
            className="min-w-[48px] min-h-[36px] px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 active:scale-95 transition shadow">
            <Menu size={16} />
            <span>Menu</span>
          </button>
        </div>
      </header>

      {/* --- 2. GAME MAP / PLAYING BOARD (FLEX-1 AUTO FIT WITHOUT OVERLAP) --- */}
      <main className="flex-1 w-full min-h-0 relative flex items-center justify-center bg-slate-950 p-1 sm:p-2 overflow-hidden">
        <canvas
          ref={canvasRef}
          width={canvasWidth}
          height={canvasHeight}
          style={{
            aspectRatio: `${canvasWidth} / ${canvasHeight}`,
          }}
          className="object-contain max-w-full max-h-full rounded-2xl shadow-2xl border border-slate-800/80"
        />
      </main>

      {/* --- 3. GAP & 4. VIRTUAL D-PAD & 5. FOOTER CONTAINER --- */}
      <div className="w-full shrink-0 flex flex-col items-center justify-center bg-slate-900/90 border-t border-slate-800/80 px-3 pt-1.5 pb-2 z-20 shadow-inner">
        {/* VIRTUAL D-PAD (Dedicated non-overlapping controls) */}
        <div className="flex flex-col items-center gap-1 touch-none select-none">
          {/* UP BUTTON */}
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              requestDirection({ x: 0, y: -1 });
              triggerHaptic(15);
            }}
            aria-label="Move Up"
            className="w-14 h-10 sm:w-16 sm:h-12 bg-gradient-to-b from-slate-700 to-slate-800 active:from-emerald-500 active:to-emerald-600 text-white rounded-xl flex items-center justify-center font-black text-xl shadow-[0_3px_0_#0f172a] active:shadow-none active:translate-y-0.5 transition-all border border-slate-600/80 cursor-pointer">
            ▲
          </button>

          {/* LEFT - HUB - RIGHT ROW */}
          <div className="flex gap-2 items-center">
            {/* LEFT BUTTON */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                requestDirection({ x: -1, y: 0 });
                triggerHaptic(15);
              }}
              aria-label="Move Left"
              className="w-14 h-10 sm:w-16 sm:h-12 bg-gradient-to-b from-slate-700 to-slate-800 active:from-emerald-500 active:to-emerald-600 text-white rounded-xl flex items-center justify-center font-black text-xl shadow-[0_3px_0_#0f172a] active:shadow-none active:translate-y-0.5 transition-all border border-slate-600/80 cursor-pointer">
              ◀
            </button>

            {/* Center Status Hub */}
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-slate-950 border border-slate-700 flex flex-col items-center justify-center text-[10px] text-emerald-400 font-bold tracking-wider">
              <Sparkles size={12} className="text-emerald-400 mb-0.5" />
              <span>PAD</span>
            </div>

            {/* RIGHT BUTTON */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.preventDefault();
                e.stopPropagation();
                requestDirection({ x: 1, y: 0 });
                triggerHaptic(15);
              }}
              aria-label="Move Right"
              className="w-14 h-10 sm:w-16 sm:h-12 bg-gradient-to-b from-slate-700 to-slate-800 active:from-emerald-500 active:to-emerald-600 text-white rounded-xl flex items-center justify-center font-black text-xl shadow-[0_3px_0_#0f172a] active:shadow-none active:translate-y-0.5 transition-all border border-slate-600/80 cursor-pointer">
              ▶
            </button>
          </div>

          {/* DOWN BUTTON */}
          <button
            type="button"
            onPointerDown={(e) => {
              e.preventDefault();
              e.stopPropagation();
              requestDirection({ x: 0, y: 1 });
              triggerHaptic(15);
            }}
            aria-label="Move Down"
            className="w-14 h-10 sm:w-16 sm:h-12 bg-gradient-to-b from-slate-700 to-slate-800 active:from-emerald-500 active:to-emerald-600 text-white rounded-xl flex items-center justify-center font-black text-xl shadow-[0_3px_0_#0f172a] active:shadow-none active:translate-y-0.5 transition-all border border-slate-600/80 cursor-pointer">
            ▼
          </button>
        </div>

        {/* 5. FOOTER / BOTTOM BAR */}
        <footer className="w-full max-w-sm flex items-center justify-between text-[11px] text-slate-400 font-medium mt-1 px-2">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Swipe or D-Pad to Turn
          </span>
          <span className="text-slate-500 text-[10px]">
            Snake 26s Arcade
          </span>
        </footer>
      </div>

      {/* ========================================================================= */}
      {/* --- START MENU OVERLAY --- */}
      {/* ========================================================================= */}
      {gameState.status === 'START' && (
        <MenuOverlay tone="neutral" zIndex={40}>
          <div className="w-full max-w-md bg-slate-900/95 border-2 border-emerald-500/60 rounded-3xl p-6 md:p-8 flex flex-col items-center shadow-2xl text-center backdrop-blur-md">
            <div className="flex items-center justify-center w-16 h-16 bg-emerald-500/20 rounded-2xl border border-emerald-400/40 mb-3 text-emerald-400">
              <Zap size={32} />
            </div>

            <h1 className="text-3xl md:text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-yellow-300 mb-1">
              SNAKE 26s
            </h1>
            <p className="text-xs font-semibold text-emerald-400/90 mb-4 tracking-wide">
              Cartoon Mobile Arcade • Slither &amp; Gulp Bouncy Frogs
            </p>

            {/* Selected Map Card */}
            <div className="w-full bg-slate-800/90 border border-slate-700 rounded-2xl p-3 mb-2.5 flex items-center justify-between">
              <div className="text-left">
                <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                  Arena Map
                </div>
                <div className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: currentMap.accentColor }}
                  />
                  {currentMap.name}
                </div>
              </div>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsMapModalOpen(true);
                }}
                className="min-w-[48px] min-h-[44px] px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-bold text-emerald-400 transition">
                Change
              </button>
            </div>

            {/* Selected Snake Skin Card */}
            <div className="w-full bg-slate-800/90 border border-slate-700 rounded-2xl p-3 mb-2.5 flex items-center justify-between">
              <div className="text-left">
                <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                  Snake Color
                </div>
                <div className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: currentSkin.primary }}
                  />
                  {currentSkin.name}
                </div>
              </div>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsSkinModalOpen(true);
                }}
                className="min-w-[48px] min-h-[44px] px-3 py-1.5 bg-slate-700 hover:bg-slate-600 rounded-xl text-xs font-bold text-emerald-400 transition">
                Customize
              </button>
            </div>

            {/* Speed Selection */}
            <div className="w-full bg-slate-800/90 border border-slate-700 rounded-2xl p-3 mb-5">
              <div className="flex items-center justify-between mb-2">
                <div className="text-[10px] uppercase tracking-wider text-slate-400 font-bold flex items-center gap-1">
                  <Zap size={12} className="text-yellow-400" />
                  Speed Level
                </div>
                <div
                  className="text-[10px] font-bold px-1.5 py-0.5 rounded"
                  style={{
                    color: currentSpeedConfig.color,
                    backgroundColor: 'rgba(0,0,0,0.3)',
                  }}>
                  {currentSpeedConfig.sublabel}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['BEGINNER', 'AMATEUR', 'PRO'] as SpeedMode[]).map((mode) => {
                  const isSelected = speedMode === mode;
                  const cfg = SPEED_PRESETS[mode];
                  return (
                    <button
                      key={mode}
                      onClick={() => handleSelectSpeed(mode)}
                      className={`min-h-[44px] py-2 px-1 rounded-xl text-xs font-black transition flex flex-col items-center justify-center border ${
                        isSelected
                          ? 'border-emerald-400 shadow-md scale-102'
                          : 'bg-slate-900/60 border-slate-700 text-slate-400 hover:text-slate-200'
                      }`}
                      style={{
                        backgroundColor: isSelected
                          ? 'rgba(16, 185, 129, 0.25)'
                          : undefined,
                        color: isSelected ? cfg.color : undefined,
                        borderColor: isSelected ? cfg.color : undefined,
                      }}>
                      <span>{cfg.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Start Game Button */}
            <button
              ref={startBtnRef}
              autoFocus
              onClick={initGame}
              data-testid="start-button"
              className="w-full min-w-[48px] min-h-[48px] bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-lg py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-lg active:scale-95 transition mb-2.5">
              <Play size={22} className="fill-current" />
              <span>START GAME</span>
            </button>

            {/* How to Play Guide Button */}
            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsHowToPlayOpen(true);
              }}
              className="w-full min-w-[48px] min-h-[44px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs md:text-sm py-2 px-4 rounded-xl flex items-center justify-center gap-2 transition border border-slate-700">
              <HelpCircle size={16} />
              <span>How To Play</span>
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ========================================================================= */}
      {/* --- GAME MENU / PAUSE OVERLAY --- */}
      {/* ========================================================================= */}
      {isGameMenuOpen && (
        <MenuOverlay tone="neutral" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500/60 rounded-3xl p-6 md:p-8 flex flex-col items-center shadow-2xl text-center backdrop-blur-md">
            <h2 className="text-2xl md:text-3xl font-black text-yellow-400 mb-5 flex items-center gap-2">
              <Pause size={24} />
              PAUSE &amp; SETTINGS
            </h2>

            <div className="w-full flex flex-col gap-2.5 mb-4">
              {/* Resume */}
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGameMenuOpen(false);
                }}
                className="w-full min-w-[48px] min-h-[48px] bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-base py-3 px-4 rounded-2xl flex items-center justify-center gap-2 transition active:scale-95">
                <Play size={18} />
                <span>Resume Game</span>
              </button>

              {/* Restart */}
              <button
                onClick={() => {
                  initGame();
                }}
                className="w-full min-w-[48px] min-h-[48px] bg-slate-800 hover:bg-slate-700 text-white font-bold text-base py-3 px-4 rounded-2xl flex items-center justify-center gap-2 transition border border-slate-700 active:scale-95">
                <RotateCw size={18} />
                <span>Restart Arena</span>
              </button>

              {/* Speed Mode Selector */}
              <div className="w-full bg-slate-800/80 border border-slate-700 rounded-2xl p-3 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <Zap size={14} className="text-yellow-400" />
                    Movement Speed
                  </span>
                  <span
                    className="text-[11px] font-bold"
                    style={{ color: currentSpeedConfig.color }}>
                    {currentSpeedConfig.label} (
                    {currentSpeedConfig.stepIntervalSec}s)
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['BEGINNER', 'AMATEUR', 'PRO'] as SpeedMode[]).map((mode) => {
                    const isSelected = speedMode === mode;
                    const cfg = SPEED_PRESETS[mode];
                    return (
                      <button
                        key={mode}
                        onClick={() => handleSelectSpeed(mode)}
                        className={`min-h-[42px] py-1.5 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center border ${
                          isSelected
                            ? 'border-emerald-400 bg-emerald-500/25 font-black shadow'
                            : 'bg-slate-900/60 border-slate-700 text-slate-400 hover:text-slate-200'
                        }`}
                        style={{
                          color: isSelected ? cfg.color : undefined,
                          borderColor: isSelected ? cfg.color : undefined,
                        }}>
                        {cfg.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Independent Music & Sound Toggles */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleToggleSfx}
                  className={`min-w-[48px] min-h-[48px] py-2.5 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    isSfxMuted
                      ? 'bg-rose-950/50 border-rose-700 text-rose-300'
                      : 'bg-slate-800 border-emerald-600 text-emerald-300'
                  }`}>
                  {isSfxMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
                  <span>Sound: {isSfxMuted ? 'OFF' : 'ON'}</span>
                </button>

                <button
                  onClick={handleToggleMusic}
                  className={`min-w-[48px] min-h-[48px] py-2.5 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                    isMusicMuted
                      ? 'bg-rose-950/50 border-rose-700 text-rose-300'
                      : 'bg-slate-800 border-emerald-600 text-emerald-300'
                  }`}>
                  <Music size={16} />
                  <span>Music: {isMusicMuted ? 'OFF' : 'ON'}</span>
                </button>
              </div>

              {/* Vibration Toggle */}
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHapticEnabled((prev) => !prev);
                  if (!isHapticEnabled) triggerHaptic(50);
                }}
                className={`w-full min-w-[48px] min-h-[48px] py-2.5 px-3 rounded-2xl border text-xs font-bold flex items-center justify-center gap-2 transition ${
                  isHapticEnabled
                    ? 'bg-slate-800 border-slate-700 text-slate-200'
                    : 'bg-slate-800/40 border-slate-800 text-slate-500'
                }`}>
                <Zap size={16} />
                <span>
                  Haptic Vibration:{' '}
                  {isHapticEnabled ? 'ENABLED' : 'DISABLED'}
                </span>
              </button>

              {/* How to play */}
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(true);
                }}
                className="w-full min-w-[48px] min-h-[48px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs md:text-sm py-2 px-4 rounded-2xl flex items-center justify-center gap-2 transition border border-slate-700">
                <HelpCircle size={16} />
                <span>How to Play Guide</span>
              </button>

              {/* Quit to Main Menu */}
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsGameMenuOpen(false);
                  setGameState((prev) => ({ ...prev, status: 'START' }));
                }}
                className="w-full min-w-[48px] min-h-[48px] bg-rose-900/60 hover:bg-rose-800 text-rose-200 font-bold text-sm py-2.5 px-4 rounded-2xl flex items-center justify-center gap-2 transition border border-rose-700/60">
                <span>Quit to Main Menu</span>
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}

      {/* ========================================================================= */}
      {/* --- HOW TO PLAY GUIDE MODAL --- */}
      {/* ========================================================================= */}
      {isHowToPlayOpen && (
        <MenuOverlay tone="neutral" zIndex={60}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 md:p-8 flex flex-col items-center shadow-2xl text-left backdrop-blur-md">
            <div className="w-full flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-xl md:text-2xl font-black text-emerald-400 flex items-center gap-2">
                <HelpCircle size={22} />
                How To Play
              </h3>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsHowToPlayOpen(false);
                }}
                className="min-w-[48px] min-h-[48px] p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 flex items-center justify-center">
                <X size={20} />
              </button>
            </div>

            <div className="flex flex-col gap-2.5 text-xs md:text-sm text-slate-300 mb-5">
              <div className="flex items-start gap-2.5 bg-slate-800/60 p-2.5 rounded-xl">
                <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 font-bold">
                  1
                </div>
                <div>
                  <strong className="text-white">Slither &amp; Steer:</strong>{' '}
                  Use <span className="text-emerald-300">Arrow Keys / WASD</span>,{' '}
                  <span className="text-emerald-300">Touch Swipe</span>, or the{' '}
                  <span className="text-emerald-300">Virtual D-Pad</span>.
                </div>
              </div>

              <div className="flex items-start gap-2.5 bg-slate-800/60 p-2.5 rounded-xl">
                <div className="w-6 h-6 rounded-full bg-yellow-500/20 text-yellow-400 flex items-center justify-center shrink-0 font-bold">
                  2
                </div>
                <div>
                  <strong className="text-white">Gulp Bouncy Frogs:</strong>{' '}
                  Each cute cartoon frog gives{' '}
                  <span className="text-yellow-400 font-bold">+10 points</span>{' '}
                  and extends your snake tail.
                </div>
              </div>

              <div className="flex items-start gap-2.5 bg-slate-800/60 p-2.5 rounded-xl">
                <div className="w-6 h-6 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 font-bold">
                  3
                </div>
                <div>
                  <strong className="text-white">Avoid Crashes:</strong> Do not
                  hit the outer walls, your own snake body, or obstacles.
                </div>
              </div>

              <div className="flex items-start gap-2.5 bg-slate-800/60 p-2.5 rounded-xl">
                <div className="w-6 h-6 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0 font-bold">
                  4
                </div>
                <div>
                  <strong className="text-white">3 Speed Modes:</strong> Choose{' '}
                  <span className="text-emerald-400">BEGINNER</span> (~0.20s),{' '}
                  <span className="text-sky-400">AMATEUR</span> (~0.14s), or{' '}
                  <span className="text-rose-400">PRO</span> (~0.09s).
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsHowToPlayOpen(false);
              }}
              className="w-full min-w-[48px] min-h-[48px] bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-2xl text-center transition active:scale-95 shadow">
              Close Guide
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ========================================================================= */}
      {/* --- MAP SELECTION MODAL --- */}
      {/* ========================================================================= */}
      {isMapModalOpen && (
        <MenuOverlay tone="neutral" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 flex flex-col items-center shadow-2xl text-left backdrop-blur-md">
            <div className="w-full flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-xl font-black text-yellow-400">
                Select Arena Map
              </h3>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsMapModalOpen(false);
                }}
                className="min-w-[48px] min-h-[48px] p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 flex items-center justify-center">
                <X size={20} />
              </button>
            </div>

            <div className="w-full flex flex-col gap-2.5 max-h-[60vh] overflow-y-auto touch-auto pr-1 mb-4">
              {MAPS.map((map, index) => {
                const isSelected = index === selectedMapIndex;
                const mapBest = highScores[map.id] || 0;
                return (
                  <button
                    key={map.id}
                    onClick={() => {
                      gameAudio.playConfirmSelect();
                      setSelectedMapIndex(index);
                      setIsMapModalOpen(false);
                    }}
                    className={`w-full min-w-[48px] min-h-[48px] p-3 rounded-2xl border text-left flex items-center justify-between transition ${
                      isSelected
                        ? 'bg-slate-800 border-emerald-400 shadow-md'
                        : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800/50'
                    }`}>
                    <div>
                      <div className="font-bold text-sm text-white flex items-center gap-2">
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: map.accentColor }}
                        />
                        {map.name}
                        {isSelected && (
                          <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-semibold">
                            ACTIVE
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5 line-clamp-1">
                        {map.description}
                      </div>
                    </div>
                    <div className="text-right shrink-0 ml-2">
                      <div className="text-[10px] text-slate-500 uppercase font-bold">
                        Best
                      </div>
                      <div className="text-xs font-bold text-yellow-400">
                        {mapBest}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsMapModalOpen(false);
              }}
              className="w-full min-w-[48px] min-h-[48px] bg-slate-800 hover:bg-slate-700 text-white font-bold py-2.5 px-4 rounded-2xl transition text-center">
              Done
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ========================================================================= */}
      {/* --- SNAKE SKIN CUSTOMIZATION MODAL --- */}
      {/* ========================================================================= */}
      {isSkinModalOpen && (
        <MenuOverlay tone="neutral" zIndex={50}>
          <div className="w-full max-w-md bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 flex flex-col items-center shadow-2xl text-left backdrop-blur-md">
            <div className="w-full flex items-center justify-between mb-4 border-b border-slate-800 pb-3">
              <h3 className="text-xl font-black text-yellow-400 flex items-center gap-2">
                <Palette size={20} />
                Snake Color Palette
              </h3>
              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setIsSkinModalOpen(false);
                }}
                className="min-w-[48px] min-h-[48px] p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 flex items-center justify-center">
                <X size={20} />
              </button>
            </div>

            <div className="w-full grid grid-cols-2 gap-2.5 mb-4 max-h-[55vh] overflow-y-auto touch-auto pr-1">
              {SNAKE_SKINS.map((skin, index) => {
                const isSelected = index === selectedSkinIndex;
                return (
                  <button
                    key={skin.id}
                    onClick={() => {
                      gameAudio.playConfirmSelect();
                      setSelectedSkinIndex(index);
                      setIsSkinModalOpen(false);
                    }}
                    className={`min-w-[48px] min-h-[48px] p-3 rounded-2xl border flex flex-col items-center gap-2 transition ${
                      isSelected
                        ? 'bg-slate-800 border-emerald-400 shadow-lg scale-102'
                        : 'bg-slate-900/80 border-slate-800 hover:bg-slate-800/60'
                    }`}>
                    <div className="flex items-center gap-1.5">
                      <span
                        className="w-5 h-5 rounded-full shadow-inner"
                        style={{ backgroundColor: skin.primary }}
                      />
                      <span
                        className="w-4 h-4 rounded-full shadow-inner"
                        style={{ backgroundColor: skin.secondary }}
                      />
                      <span
                        className="w-3 h-3 rounded-full shadow-inner"
                        style={{ backgroundColor: skin.glow }}
                      />
                    </div>
                    <span className="text-xs font-bold text-white">
                      {skin.name}
                    </span>
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => {
                gameAudio.playCrispClick();
                setIsSkinModalOpen(false);
              }}
              className="w-full min-w-[48px] min-h-[48px] bg-slate-800 hover:bg-slate-700 text-white font-bold py-2.5 px-4 rounded-2xl transition text-center">
              Done
            </button>
          </div>
        </MenuOverlay>
      )}

      {/* ========================================================================= */}
      {/* --- GAME OVER OVERLAY --- */}
      {/* ========================================================================= */}
      {gameState.status === 'GAME_OVER' && (
        <MenuOverlay tone="danger" zIndex={40}>
          <div className="w-full max-w-md bg-slate-900/95 border-2 border-rose-500/80 rounded-3xl p-6 md:p-8 flex flex-col items-center shadow-2xl text-center backdrop-blur-md">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mb-3 border border-rose-500/40">
              <RotateCw size={32} className="animate-pulse" />
            </div>

            <h2 className="text-3xl md:text-4xl font-black text-rose-400 mb-1">
              GAME OVER
            </h2>
            <p className="text-xs text-slate-400 mb-5">
              Your snake collided with an arena obstacle or wall!
            </p>

            {/* Score & Best Comparison */}
            <div className="w-full bg-slate-800/90 border border-slate-700 rounded-2xl p-4 mb-5 flex justify-around">
              <div>
                <div className="text-xs text-slate-400 font-medium">
                  Final Score
                </div>
                <div className="text-2xl md:text-3xl font-black text-white">
                  {gameState.score}
                </div>
              </div>
              <div className="w-px bg-slate-700" />
              <div>
                <div className="text-xs text-slate-400 font-medium">
                  Map Best ({currentMap.name})
                </div>
                <div className="text-2xl md:text-3xl font-black text-yellow-400">
                  {highScores[currentMap.id] || gameState.score}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="w-full flex flex-col gap-2.5">
              <button
                ref={tryAgainBtnRef}
                autoFocus
                onClick={initGame}
                data-testid="start-button"
                className="w-full min-w-[48px] min-h-[48px] bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-lg py-3.5 px-6 rounded-2xl flex items-center justify-center gap-2 shadow-lg active:scale-95 transition">
                <RotateCw size={20} />
                <span>PLAY AGAIN</span>
              </button>

              <button
                onClick={() => {
                  gameAudio.playCrispClick();
                  setGameState((prev) => ({ ...prev, status: 'START' }));
                }}
                className="w-full min-w-[48px] min-h-[48px] bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm py-2.5 px-4 rounded-2xl transition border border-slate-700">
                Back to Main Menu
              </button>
            </div>
          </div>
        </MenuOverlay>
      )}
    </div>
  );
}
